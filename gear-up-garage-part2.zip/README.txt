GEAR UP GARAGE, PART 2: TEST TRACK  (TEKS 5.7B: design a simple experimental investigation that tests the effect of force on an object in a system)
Built around Mystery Lab Issue 6: Mission Control. The numbers in the virtual labs match the comic.

TO PUT IT ONLINE
Netlify: drag this whole folder (unzipped) onto app.netlify.com/drop.

THE SIX STATIONS
1 Briefing Room: the seven-step mission checklist, systems, testable questions, variable / measure / constant
2 Ramp Lab: a virtual lab. How does ramp height affect how far a car rolls?
3 Balloon Rocket Hall: a virtual lab. How does the amount of air affect how far a balloon rocket travels?
4 Air-Glide Disc: a virtual lab. How does an air cushion affect how far a disc glides? (friction)
5 Judges' Table: spot the mistake, averages, read the graph, pick the fair plan
6 Derby Day: students plan their own investigation (ramp or rocket), run it, then tune the winning car and rocket from their data

HOW THE VIRTUAL LABS WORK (each lab follows the seven steps)
1 Question  2 Predict  3 Plan (change, measure, keep the same)  4 Trials (3 good trials for each setting, measured on a tape measure)
5 Data (find the averages)  6 Pattern (and pick the matching graph)  7 Explain (claim, evidence, reasoning)
Results vary a little from trial to trial, like a real lab. In Standard and Challenge a trial now and then does not count (the car hits a table leg), and students decide to redo it.
Easy mode: the plan is filled in, measuring is automatic, and averages are filled in.
Challenge mode: more settings (4 books), a second trial that does not count, and a "use your pattern to predict" question.

CHARACTERS AND PICTURES: all included (images folder).
TEACHER CODE CHECK: teacher-check.html is not linked from the game. Type a student's name to see that student's six level codes.
PRIVACY: nothing is sent anywhere. Name, mode, and progress are kept only in the browser tab.
