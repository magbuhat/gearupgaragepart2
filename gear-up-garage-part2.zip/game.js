/* Gear Up Garage, Part 2: Test Track (TEKS 5.7B) for 5th grade science.
   No student data leaves the browser. The name, mode, and progress live in sessionStorage only. */
(function () {
  'use strict';

  /* ---------- tiny helpers ---------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const NS = 'http://www.w3.org/2000/svg';
  function h(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function s(tag, attrs, parent) {
    const e = document.createElementNS(NS, tag);
    for (const k in (attrs || {})) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  const app = $('#app');

  /* ---------- state ---------- */
  const BADGES = [
    { name: 'Mission Briefing', label: 'BRIEFING', tier: 'bronze' }, { name: 'Ramp Lab', label: 'RAMP LAB', tier: 'bronze' },
    { name: 'Balloon Rocket', label: 'ROCKET', tier: 'silver' }, { name: 'Air-Glide Disc', label: 'AIR-GLIDE', tier: 'silver' },
    { name: 'Fair Test Judge', label: 'FAIR TEST', tier: 'gold' }, { name: 'Derby Champion', label: 'DERBY', tier: 'gold' }
  ];
  const RANKS = ['Recruit', 'Lab Assistant', 'Ramp Tester', 'Rocket Scientist', 'Glide Engineer', 'Fair Test Judge', 'Derby Day Champion'];
  const METER = [0, 20, 40, 60, 80, 90, 100];
  const state = { name: '', mode: 'standard', path: 'full', done: 0, level: 0, hints: 0, stars: [] };

  function save() { try { sessionStorage.setItem('gar2', JSON.stringify({ name: state.name, mode: state.mode, path: state.path, done: state.done, stars: state.stars })); } catch (e) { /* storage can be blocked */ } }
  function load() {
    try {
      const d = JSON.parse(sessionStorage.getItem('gar2') || 'null');
      if (d) { state.name = d.name || ''; state.mode = d.mode || 'standard'; state.path = d.path || 'full'; state.done = d.done || 0; state.stars = Array.isArray(d.stars) ? d.stars : []; }
    } catch (e) { /* ignore */ }
  }
  const STAR_SVG = '<svg class="badge-star" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.8 6 6.5.8-4.8 4.5 1.3 6.5L12 17l-5.8 3.3 1.3-6.5L2.7 9.3l6.5-.8z" fill="#ffd23f" stroke="#0b1736" stroke-width="1.6" stroke-linejoin="round"/></svg>';
  function fill(t) { return String(t).replace(/\{name\}/g, state.name || 'Engineer'); }
  function levelCode(n) {
    const ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no 0/O or 1/I/L look-alikes
    let x = 2166136261; const str = (state.name.trim().toLowerCase()) + '|gar2|' + n;
    for (let i = 0; i < str.length; i++) { x ^= str.charCodeAt(i); x = Math.imul(x, 16777619); }
    x >>>= 0; let out = '';
    for (let i = 0; i < 4; i++) { out += ALPHA[x % ALPHA.length]; x = Math.floor(x / ALPHA.length); }
    return 'L' + n + '-' + out;
  }

  /* ---------- toast, speech ---------- */
  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
  }
  function textOf(el) {
    const c = el.cloneNode(true);
    $$('button,img', c).forEach(n => n.remove());
    return c.textContent.replace(/\s+/g, ' ').trim();
  }
  function speak(text) {
    if (!('speechSynthesis' in window)) { toast('Read-aloud is not available on this device.'); return; }
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.95; u.lang = 'en-US';
      window.speechSynthesis.speak(u);
    } catch (e) { toast('Read-aloud is not available on this device.'); }
  }
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-say-from]');
    if (b) { const src = $(b.getAttribute('data-say-from'), b.closest('.screen')); if (src) speak(fill(textOf(src))); }
  });

  /* ---------- screens, HUD ---------- */
  const screens = $$('.screen');
  let activeBoards = [];
  function stopBoards() { activeBoards.forEach(b => b.stopFlow()); activeBoards = []; }
  function setScene(c) { app.className = c; }
  function updateHUD() {
    $('#hud-name').textContent = 'Engineer ' + (state.name || '');
    $('#hud-rank').textContent = RANKS[Math.min(state.done, RANKS.length - 1)];
    const pct = METER[Math.min(state.done, METER.length - 1)];
    $('#meter-fill').style.width = pct + '%';
    $('#meter-pct').textContent = pct + '%';
  }
  function applyNames() { $$('.tpl').forEach(el => { if (!el.dataset.tpl) el.dataset.tpl = el.textContent; el.textContent = fill(el.dataset.tpl); }); }
  function show(id, scene) {
    stopBoards();
    if (window.speechSynthesis) { try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } }
    screens.forEach(sc => { sc.hidden = sc.id !== 's-' + id; });
    if (scene) setScene(scene);
    $('#hud').hidden = (id === 'title' || id === 'name' || id === 'lightshow');
    applyNames(); updateHUD();
    window.scrollTo(0, 0);
  }


  /* =====================================================================
     DRAGGING: works with mouse, finger, and pen. A tap (no movement) selects instead.
     ===================================================================== */
  function drag(el, onTap, onDrop) {
    el.addEventListener('pointerdown', e => {
      if (e.button > 0 || el.classList.contains('used')) return;
      const sx = e.clientX, sy = e.clientY; let ghost = null, moved = false;
      try { el.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
      const mv = ev => {
        if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) > 8) {
          moved = true; ghost = el.cloneNode(true); ghost.classList.add('drag-ghost'); ghost.classList.remove('selected');
          document.body.appendChild(ghost);
        }
        if (ghost) { ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px'; }
      };
      const end = () => { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', cancel); if (ghost) ghost.remove(); };
      const up = ev => { end(); if (moved) onDrop(ev.clientX, ev.clientY); else onTap(); };
      const cancel = () => end();
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', cancel);
    });
  }


  /* =====================================================================
     TASK FRAMEWORK: header, helper (Zib), hint ladders, next button
     ===================================================================== */
  const POSES = { wave: 'images/bolt-wave.png', think: 'images/bolt-think.png', worried: 'images/bolt-worried.png', cheer: 'images/bolt-cheer.png' };
  const T = { body: $('#task-body'), next: $('#btn-task-next'), act: $('#btn-task-action'), spoken: '' };
  function say(text, pose, tone) {
    const root = $('#helper');
    $('#helper-text').textContent = fill(text);
    const img = $('#helper-img'); img.src = POSES[pose || 'wave'];
    root.className = 'helper' + (tone ? ' ' + tone : '');
    void root.offsetWidth; root.classList.add('bounce');
  }
  function ladder(steps) {
    let n = 0;
    return { give(prefix) { state.hints++; const st = steps[Math.min(n, steps.length - 1)]; n++; const r = st(); say((prefix || '') + r.text, r.pose || 'think', r.tone); }, count() { return n; } };
  }
  $('#helper').addEventListener('click', () => speak($('#helper-text').textContent));
  const later = (fn, ms) => { const tk = T.tok; return setTimeout(() => { if (T.tok === tk) fn(); }, ms); };
  function openTask(ctx, cfg) {
    T.tok = (T.tok || 0) + 1;
    stopBoards();
    $('#task-step').textContent = 'Task ' + (ctx.index + 1) + ' of ' + ctx.total;
    $('#task-title').textContent = cfg.title;
    setPrompt(cfg.prompt);
    T.body.innerHTML = '';
    T.act.hidden = !cfg.action; T.act.textContent = cfg.action || ''; T.act.disabled = false; T.act.onclick = null;
    T.next.disabled = true; T.next.textContent = ctx.index === ctx.total - 1 ? 'Finish' : 'Next'; T.next.onclick = null;
    say(state.mode === 'easy' ? cfg.tip : cfg.intro, 'wave');
    show('task');
  }
  function setPrompt(t) { $('#task-prompt').textContent = fill(t); }
  $('#btn-task-say').addEventListener('click', () => speak(fill($('#task-title').textContent + '. ' + $('#task-prompt').textContent)));
  function finishTask(ctx) {
    T.act.hidden = true; T.next.disabled = false; T.next.onclick = ctx.next;
    T.next.focus({ preventScroll: true });
  }
  function choiceRow(options, onPick) {
    const row = h('div', 'choices'); const btns = [];
    options.forEach(o => {
      const b = h('button', 'choice'); b.type = 'button'; b.textContent = o.text; b.dataset.key = o.key; b.setAttribute('aria-pressed', 'false');
      b.addEventListener('click', () => { if (row.dataset.locked) return; btns.forEach(x => { x.setAttribute('aria-pressed', 'false'); x.classList.remove('wrong', 'right', 'glow-hint'); }); b.setAttribute('aria-pressed', 'true'); onPick(o.key, b); });
      row.appendChild(b); btns.push(b);
    });
    return { el: row, btns, find: k => btns.find(b => b.dataset.key === k), lock() { row.dataset.locked = '1'; } };
  }

  /* ---------- connection phrases (vocabulary) ---------- */

  function connectRun(ctx, cfg) {
    const VOCAB = cfg.vocab;
    const ids = cfg.terms[state.mode] || cfg.terms.standard;
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: 'Check', intro: cfg.intro, tip: cfg.tip });
    const card = h('div', 'fill-card conn-card');
    const bank = h('div', 'word-bank');
    T.body.append(card, bank);
    const value = {}, blanks = {}, chips = {}; let sel = null;
    ids.forEach(id => {
      const row = h('div', 'conn-row'); const term = h('span', 'conn-term', VOCAB[id].term); const eq = h('span', 'conn-eq', '='); const bl = h('span', 'blank');
      bl.dataset.id = id; bl.tabIndex = 0; bl.setAttribute('role', 'button'); bl.setAttribute('aria-label', 'Connection phrase for ' + VOCAB[id].term);
      row.append(term, eq, bl); card.appendChild(row); value[id] = null; blanks[id] = bl;
    });
    const extra = shuffle(cfg.distractors || []).slice(0, state.mode === 'easy' ? 1 : 2);
    shuffle(ids.map(id => VOCAB[id].phrase).concat(extra)).forEach(w => {
      const c = h('button', 'chip'); c.type = 'button'; c.textContent = w; c.dataset.word = w; chips[w] = c;
      drag(c,
        () => { Object.values(chips).forEach(x => x.classList.remove('selected')); if (sel === w) sel = null; else { sel = w; c.classList.add('selected'); } },
        (x, y) => { const el = document.elementFromPoint(x, y); const b = el && el.closest ? el.closest('.blank') : null; if (b) put(b.dataset.id, w); });
      bank.appendChild(c);
    });
    function put(id, w) {
      if (value[id]) chips[value[id]].classList.remove('used');
      ids.forEach(k => { if (value[k] === w) { value[k] = null; blanks[k].textContent = ''; blanks[k].className = 'blank'; } });
      value[id] = w; blanks[id].textContent = w; blanks[id].className = 'blank';
      chips[w].classList.remove('selected', 'glow-hint'); chips[w].classList.add('used'); sel = null;
      Object.values(chips).forEach(x => x.classList.remove('selected'));
    }
    function clear(id) { const w = value[id]; if (!w) return; chips[w].classList.remove('used'); value[id] = null; blanks[id].textContent = ''; blanks[id].className = 'blank'; }
    ids.forEach(id => {
      const b = blanks[id];
      b.addEventListener('click', () => { if (sel) put(id, sel); else clear(id); });
      b.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); b.click(); } });
    });
    const firstWrong = () => ids.find(id => value[id] !== VOCAB[id].phrase);
    const hl = ladder([
      () => ({ text: cfg.hint1 || 'Think about what you saw. Which phrase tells what that term means?' }),
      () => { const id = firstWrong(); if (id) chips[VOCAB[id].phrase].classList.add('glow-hint'); return { text: 'The glowing phrase fits the first term that is not right yet.' }; },
      () => { const id = firstWrong(); if (id) { put(id, VOCAB[id].phrase); blanks[id].classList.add('right'); } return { text: 'I connected one for you as an example. Now finish the rest!' }; }
    ]);

    T.act.onclick = () => {
      if (ids.some(id => !value[id])) { say('Fill every blank first. Drag a phrase to each term.', 'think'); return; }
      let allRight = true;
      ids.forEach(id => { const r = value[id] === VOCAB[id].phrase; blanks[id].className = 'blank ' + (r ? 'right' : 'wrong'); if (!r) allRight = false; });
      if (allRight) {
        const synList = (cfg.syn && (cfg.syn[state.mode] || cfg.syn.standard)) || [];
        Object.values(chips).forEach(c => c.classList.add('used'));
        T.act.hidden = true;
        if (!synList.length) { say(cfg.doneMsg || 'Perfect connections!', 'cheer', 'good'); finishTask(ctx); return; }
        say('Perfect connections! Now a thinking question: the same idea can be said different ways.', 'cheer', 'good');
        setTimeout(() => askSyn(0), 1600);
      } else {
        hl.give('Almost! ');
        setTimeout(() => ids.forEach(id => { if (value[id] !== VOCAB[id].phrase) clear(id); }), 1100);
      }
    };

    let prevRow = null;
    function askSyn(n) {
      const list = (cfg.syn && (cfg.syn[state.mode] || cfg.syn.standard)) || [];
      if (n >= list.length) { say('You connected the words and found other ways to say them. Nice thinking, Engineer ' + (state.name || '') + '!', 'cheer', 'good'); finishTask(ctx); return; }
      const v = VOCAB[list[n]];
      card.remove(); bank.remove(); if (prevRow) { prevRow.remove(); prevRow = null; }
      setPrompt('Which phrase ALSO fits ' + v.term + '? (' + v.term + ' = ' + v.phrase + ')');
      const good = shuffle(v.syn)[0];
      const wrongs = state.mode === 'easy' ? v.wrong.slice(0, 1) : v.wrong;
      const row = choiceRow(shuffle([{ key: 'good', text: good }].concat(wrongs.map((w, i) => ({ key: 'w' + i, text: w })))), (k, b) => {
        if (k === 'good') {
          b.classList.add('right'); row.lock();
          say('Yes! "' + good + '" also means ' + v.term + '. Same idea, different words!', 'cheer', 'good');
          setTimeout(() => askSyn(n + 1), 1800);
        } else { b.classList.add('wrong'); synLadder.give('Not quite. '); }
      });
      const synLadder = ladder([
        () => ({ text: 'Remember: ' + v.term + ' = ' + v.phrase + '. Which phrase says the same thing?' }),
        () => { const g = row.btns.find(x => x.dataset.key === 'good'); if (g) g.classList.add('glow-hint'); return { text: 'Look at the glowing choice. It means the same as ' + v.phrase + '.' }; }
      ]);
      T.body.appendChild(row.el); prevRow = row.el;
      say('Question ' + (n + 1) + ' of ' + list.length + '. Take your time.', 'think');
    }
  }

  /* Ask a multiple choice question. The FIRST option is the correct one (they are shuffled on screen). */
  function askChoice(parent, cfg) {
    if (cfg.prompt) setPrompt(cfg.prompt);
    const lad = ladder([
      () => ({ text: cfg.hint1 }),
      () => { if (cfg.hint2fn) cfg.hint2fn(); return { text: cfg.hint2 || 'Think about what you just saw.' }; },
      () => { const g = row.btns.find(b => b.dataset.key === 'good'); if (g) g.classList.add('glow-hint'); return { text: 'Look at the glowing choice.' }; }
    ]);
    const row = choiceRow(shuffle(cfg.options.map((t, i) => ({ key: i === 0 ? 'good' : 'w' + i, text: t }))), (k, b) => {
      if (k === 'good') { b.classList.add('right'); row.lock(); if (cfg.onGood) cfg.onGood(); }
      else { b.classList.add('wrong'); lad.give('Not quite. '); }
    });
    if (cfg.options.length >= 4) row.el.classList.add('four');
    parent.appendChild(row.el);
    return row;
  }

  /* Sort cards into bins. items: {id, label, bin, color?}. bins: {id, title, sub}. */
  function makeSorter(cfg) {
    const root = h('div', 'sorter'); const binsEl = h('div', 'bins'); const pool = h('div', 'word-bank sort-pool');
    root.append(binsEl, pool);
    const place = {}, chips = {}, boxes = {}; let sel = null, locked = false;
    function changed() { if (cfg.onChange) cfg.onChange(); }
    function putIn(id, bin) {
      if (locked) return; place[id] = bin; boxes[bin].querySelector('.bin-items').appendChild(chips[id]);
      chips[id].classList.remove('selected', 'wrong', 'right', 'glow-hint'); sel = null; Object.values(chips).forEach(c => c.classList.remove('selected')); changed();
    }
    function toPool(id) { if (locked) return; place[id] = null; pool.appendChild(chips[id]); chips[id].classList.remove('wrong', 'right'); changed(); }
    cfg.bins.forEach(b => {
      const box = h('div', 'bin'); box.dataset.bin = b.id; box.innerHTML = '<div class="bin-head"><b>' + b.title + '</b><small>' + b.sub + '</small></div><div class="bin-items"></div>';
      box.addEventListener('click', e => { if (e.target.closest('.chip')) return; if (sel) putIn(sel, b.id); });
      binsEl.appendChild(box); boxes[b.id] = box;
    });
    shuffle(cfg.items).forEach(it => {
      const c = h('button', 'chip item-chip', (it.color ? '<i class="sw" style="background:' + it.color + '"></i>' : '') + '<span>' + it.label + '</span>'); c.type = 'button'; c.dataset.id = it.id; chips[it.id] = c; place[it.id] = null;
      drag(c,
        () => { if (place[it.id]) { toPool(it.id); return; } Object.values(chips).forEach(x => x.classList.remove('selected')); if (sel === it.id) sel = null; else { sel = it.id; c.classList.add('selected'); } },
        (x, y) => { const el = document.elementFromPoint(x, y); const box = el && el.closest ? el.closest('.bin') : null; if (box) putIn(it.id, box.dataset.bin); });
      pool.appendChild(c);
    });
    return {
      el: root, place, chips,
      allPlaced() { return cfg.items.every(it => place[it.id]); },
      wrong() { return cfg.items.filter(it => place[it.id] && place[it.id] !== it.bin).map(it => it.id); },
      mark(ids, cls) { ids.forEach(id => chips[id].classList.add(cls)); },
      bounce(ids) { ids.forEach(id => { chips[id].classList.add('wrong'); setTimeout(() => { toPool(id); chips[id].classList.remove('wrong'); }, 900); }); },
      glow(ids) { ids.forEach(id => chips[id].classList.add('glow-hint')); },
      autoPlace(id) { const it = cfg.items.find(x => x.id === id); putIn(id, it.bin); chips[id].classList.add('right'); },
      lock() { locked = true; Object.values(chips).forEach(c => c.classList.add('locked')); }
    };
  }


  /* =====================================================================
     SHARED SCENES: Earth spinning, shadow clock, orbit and seasons, Moon phases, tides
     ===================================================================== */
  const SPEED = window.OBH_TEST ? (typeof window.OBH_SPEED === 'number' ? window.OBH_SPEED : 0.02) : 1; // fast for automated tests, always 1 for students
  const deg2 = d => d * Math.PI / 180;
  function fmtTime(t) {
    t = ((t % 24) + 24) % 24; let hh = Math.floor(t + 1e-9), mm = Math.round((t - hh) * 60); if (mm === 60) { hh++; mm = 0; } hh = hh % 24;
    if (hh === 12 && mm === 0) return '12:00 noon'; if (hh === 0 && mm === 0) return '12:00 midnight';
    const ap = hh < 12 ? 'a.m.' : 'p.m.'; let h12 = hh % 12; if (h12 === 0) h12 = 12; return h12 + ':' + (mm < 10 ? '0' : '') + mm + ' ' + ap;
  }
  const hourWord = t => { const k = ((Math.round(t * 4) / 4 % 24) + 24) % 24; return k === 6 ? 'sunrise' : k === 18 ? 'sunset' : k === 12 ? 'noon' : k === 0 ? 'midnight' : (k > 6 && k < 18) ? 'daytime' : 'nighttime'; };
  function pickRow(options, onPick) { // options: [{html, key, label}]
    const row = h('div', 'picks'); const btns = [];
    options.forEach(o => { const b = h('button', 'pick', o.html); b.type = 'button'; b.dataset.key = o.key; b.setAttribute('aria-label', o.label || 'choice'); b.addEventListener('click', () => { if (row.dataset.locked) return; btns.forEach(x => x.classList.remove('wrong', 'right', 'glow-hint')); onPick(o.key, b); }); row.appendChild(b); btns.push(b); });
    return { el: row, btns, lock() { row.dataset.locked = '1'; }, find: k => btns.find(b => b.dataset.key === k) };
  }
  // after a right answer, wait for the student to press a button (no auto-advance)
  function waitNext(label, fn) { T.act.hidden = false; T.act.disabled = false; T.act.textContent = label; T.act.onclick = () => { T.act.hidden = true; fn(); }; }
  function makeWrap(container, cls) { const wrap = h('div', 'board-wrap ' + (cls || '')); container.appendChild(wrap); return wrap; }
  const sceneStub = () => ({ stopFlow() { } });


  /* =====================================================================
     FORCE SCENES: arrows, spring scale, tug-of-war, friction track, heavy haul, bumper cars
     ===================================================================== */
  const NAVYC = '#0b1736';
  function arrow(parent, x1, x2, y, color, w) { // a horizontal arrow from x1 to x2
    const dir = x2 >= x1 ? 1 : -1, len = Math.abs(x2 - x1); if (len < 6) return null;
    const g = s('g', {}, parent); const head = Math.min(26, len);
    s('line', { x1, y1: y, x2: x2 - dir * (head - 4), y2: y, stroke: color, 'stroke-width': w || 12, 'stroke-linecap': 'round' }, g);
    s('polygon', { points: [x2, y, x2 - dir * head, y - 19, x2 - dir * head, y + 19].join(','), fill: color, stroke: NAVYC, 'stroke-width': 3, 'stroke-linejoin': 'round' }, g);
    return g;
  }
  function stext(parent, x, y, t, cls, anchor) { const e = s('text', { x, y, 'text-anchor': anchor || 'middle', class: 'skytxt ' + (cls || '') }, parent); e.textContent = t; return e; }
  function sliderRow(left, right, min, max, step, value, aria) {
    const row = h('div', 'slider-row', '<span>' + left + '</span><input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + value + '" aria-label="' + aria + '"><span>' + right + '</span>');
    return { row, input: row.querySelector('input') };
  }
  function trialTable(container, headers) {
    const wrap = h('div', 'trial-wrap'); const tb = h('table', 'trial-table'); const thead = h('thead'); const tr = h('tr'); headers.forEach(x => tr.appendChild(h('th', null, x))); thead.appendChild(tr); tb.appendChild(thead);
    const body = h('tbody'); tb.appendChild(body); wrap.appendChild(tb); container.appendChild(wrap);
    return { el: wrap, count: () => body.children.length, add(cells) { const r = h('tr'); cells.forEach(c => r.appendChild(h('td', null, String(c)))); body.insertBefore(r, body.firstChild); while (body.children.length > 5) body.removeChild(body.lastChild); } };
  }
  const baseScene = (container, label, cls) => { const wrap = makeWrap(container, 'skywrap ' + (cls || '')); const svgEl = s('svg', { viewBox: '0 0 800 420', class: 'board', role: 'img', 'aria-label': label }); wrap.appendChild(svgEl); return { wrap, svgEl }; };

  /* ---- 1. Arrow diagram: an object with a force arrow on each side ---- */
  function makeArrowScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'An object with force arrows pointing left and right'); const svgEl = b.svgEl;
    s('rect', { x: 0, y: 322, width: 800, height: 98, fill: 'rgba(255,255,255,.12)' }, svgEl); s('line', { x1: 0, y1: 322, x2: 800, y2: 322, stroke: '#8fa3d6', 'stroke-width': 4 }, svgEl);
    const g = s('g', {}, svgEl); const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    const api = {
      wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { },
      set(l, r, dx) {
        g.innerHTML = ''; const cx = 400 + (dx || 0), isCart = opts.object === 'cart', w = isCart ? 170 : 136;
        if (isCart) { s('rect', { x: cx - w / 2, y: 262, width: w, height: 46, rx: 8, fill: '#4aa8ff', stroke: NAVYC, 'stroke-width': 5 }, g); [-48, 48].forEach(o => { s('circle', { cx: cx + o, cy: 305, r: 17, fill: '#2b3566', stroke: NAVYC, 'stroke-width': 4 }, g); s('circle', { cx: cx + o, cy: 305, r: 5, fill: '#cfd8f5' }, g); }); }
        else { s('rect', { x: cx - w / 2, y: 224, width: w, height: 98, rx: 6, fill: '#c8905a', stroke: NAVYC, 'stroke-width': 5 }, g); s('line', { x1: cx - w / 2, y1: 256, x2: cx + w / 2, y2: 256, stroke: '#8a5a2a', 'stroke-width': 3 }, g); s('line', { x1: cx - w / 2, y1: 289, x2: cx + w / 2, y2: 289, stroke: '#8a5a2a', 'stroke-width': 3 }, g); }
        const ay = isCart ? 285 : 273;
        if (opts.moving) { const d = opts.moving > 0 ? -1 : 1; [248, 272, 296].forEach((yy, i) => s('line', { x1: cx + d * (w / 2 + 12), y1: yy + (isCart ? 6 : 0), x2: cx + d * (w / 2 + 50 + i * 12), y2: yy + (isCart ? 6 : 0), stroke: '#cfd8f5', 'stroke-width': 5, 'stroke-linecap': 'round' }, g)); stext(g, cx, 190, 'moving ' + (opts.moving > 0 ? 'right' : 'left'), 'small'); }
        if (l > 0) { const x1 = cx - w / 2 - 6; arrow(g, x1, x1 - l * 9, ay, '#ff6a5a', 14); stext(g, x1 - l * 4.5, ay - 36, l + ' N', 'big'); }
        if (r > 0) { const x1 = cx + w / 2 + 6; arrow(g, x1, x1 + r * 9, ay, '#4ac0ff', 14); stext(g, x1 + r * 4.5, ay - 36, r + ' N', 'big'); }
        api.l = l; api.r = r; api.net = r - l;
        read.innerHTML = 'Left force: <b>' + l + ' N</b> &nbsp;|&nbsp; Right force: <b>' + r + ' N</b>';
      }
    };
    api.set(opts.left || 0, opts.right || 0); return api;
  }

  /* ---- 2. Spring scale ---- */
  function makeSpringScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'A spring scale with a pointer that shows a force in newtons'); const svgEl = b.svgEl;
    s('rect', { x: 70, y: 120, width: 660, height: 170, rx: 22, fill: '#dfe7f5', stroke: NAVYC, 'stroke-width': 6 }, svgEl);
    s('path', { d: 'M70,205 q-34,-30 -50,0 q16,30 50,0', fill: 'none', stroke: '#8fa3d6', 'stroke-width': 8, 'stroke-linecap': 'round' }, svgEl); s('circle', { cx: 24, cy: 205, r: 12, fill: 'none', stroke: NAVYC, 'stroke-width': 6 }, svgEl);
    for (let i = 0; i <= 20; i++) { const x = 120 + i * 27, major = i % 2 === 0; s('line', { x1: x, y1: 170, x2: x, y2: major ? 215 : 197, stroke: NAVYC, 'stroke-width': major ? 4 : 3 }, svgEl); if (major) stext(svgEl, x, 255, String(i / 2), 'dark', 'middle'); }
    stext(svgEl, 400, 150, 'SPRING SCALE (newtons, N)', 'small dark');
    const ptr = s('g', {}, svgEl); const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    const api = { wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { }, set(v) { ptr.innerHTML = ''; const x = 120 + v * 54; s('line', { x1: x, y1: 160, x2: x, y2: 225, stroke: '#e0453a', 'stroke-width': 6, 'stroke-linecap': 'round' }, ptr); s('polygon', { points: x + ',228 ' + (x - 12) + ',250 ' + (x + 12) + ',250', fill: '#e0453a', stroke: NAVYC, 'stroke-width': 2 }, ptr); api.v = v; read.innerHTML = opts.showValue === false ? 'Read the pointer.' : 'Force: <b>' + v + ' N</b>'; } };
    api.set(opts.value === undefined ? 0 : opts.value); return api;
  }

  /* ---- 3. Tug-of-war (each kid pulls with 10 N) ---- */
  function makeTugScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'A tug-of-war with kids on both ends of a rope and a flag in the middle'); const svgEl = b.svgEl;
    s('rect', { x: 0, y: 322, width: 800, height: 98, fill: 'rgba(120,200,110,.35)' }, svgEl); s('line', { x1: 0, y1: 322, x2: 800, y2: 322, stroke: '#5a9a3a', 'stroke-width': 5 }, svgEl);
    s('line', { x1: 400, y1: 150, x2: 400, y2: 322, stroke: 'rgba(255,255,255,.7)', 'stroke-width': 3, 'stroke-dasharray': '8 8' }, svgEl); stext(svgEl, 400, 140, 'start line', 'small');
    const g = s('g', {}, svgEl); const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    const kid = (parent, x, col, dir) => { const k = s('g', {}, parent); s('line', { x1: x, y1: 300, x2: x + dir * -10, y2: 262, stroke: NAVYC, 'stroke-width': 8, 'stroke-linecap': 'round' }, k); s('line', { x1: x + dir * -10, y1: 262, x2: x + dir * 22, y2: 252, stroke: NAVYC, 'stroke-width': 7, 'stroke-linecap': 'round' }, k); s('rect', { x: x - 14 - dir * 6, y: 232, width: 24, height: 38, rx: 8, fill: col, stroke: NAVYC, 'stroke-width': 3 }, k); s('circle', { cx: x - dir * 4, cy: 218, r: 13, fill: '#ffd9a0', stroke: NAVYC, 'stroke-width': 3 }, k); };
    const api = {
      wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { },
      set(l, r) {
        g.innerHTML = ''; const dx = Math.max(-190, Math.min(190, (r - l) * 38)), fx = 400 + dx;
        s('line', { x1: 150, y1: 262, x2: 650, y2: 262, stroke: '#8a5a2a', 'stroke-width': 9, 'stroke-linecap': 'round' }, g);
        for (let i = 0; i < l; i++) kid(g, 120 + i * 44, '#2f6fe0', 1); for (let i = 0; i < r; i++) kid(g, 680 - i * 44, '#ff8a1f', -1);
        s('line', { x1: fx, y1: 180, x2: fx, y2: 262, stroke: NAVYC, 'stroke-width': 5 }, g); s('polygon', { points: fx + ',180 ' + (fx + 44) + ',196 ' + fx + ',214', fill: '#ff3b3b', stroke: NAVYC, 'stroke-width': 3 }, g);
        if (l > 0) { arrow(g, 190, 190 - l * 14 + 14 > 40 ? 190 - l * 14 : 40, 110, '#2f6fe0', 12); stext(g, 150, 80, l * 10 + ' N', 'big'); }
        if (r > 0) { arrow(g, 610, 610 + r * 14 < 760 ? 610 + r * 14 : 760, 110, '#ff8a1f', 12); stext(g, 650, 80, r * 10 + ' N', 'big'); }
        api.l = l; api.r = r; api.dx = dx;
        const word = l === r ? 'Equal forces: no change in motion' : r > l ? 'Unequal forces: the flag moves right (toward the bigger pull)' : 'Unequal forces: the flag moves left (toward the bigger pull)';
        read.innerHTML = 'Left team: <b>' + l * 10 + ' N</b> &nbsp;|&nbsp; Right team: <b>' + r * 10 + ' N</b> &nbsp;|&nbsp; <b>' + word + '</b>';
      }
    };
    api.set(opts.left === undefined ? 2 : opts.left, opts.right === undefined ? 2 : opts.right); return api;
  }

  /* ---- 4. Friction track: a block slides on ice, wood, carpet, or sand ---- */
  const SURF = { ice: { label: 'ice', mu: 0.1, fill: '#cfeaff', line: '#ffffff' }, wood: { label: 'wood', mu: 0.3, fill: '#b9814d', line: '#8a5a2a' }, carpet: { label: 'carpet', mu: 0.5, fill: '#c94a5a', line: '#8f2f3d' }, sand: { label: 'sand', mu: 0.8, fill: '#e6cf8f', line: '#b89a4a' } };
  const PUSHES = { 1: 'light', 2: 'medium', 3: 'hard' };
  const slideDist = (surf, push) => +(2 * push * push / (SURF[surf].mu * 10)).toFixed(1);
  function makeFrictionScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'A block on a track. A ruler shows how far it slides on each surface.'); const svgEl = b.svgEl;
    const surfG = s('g', {}, svgEl), dynG = s('g', {}, svgEl); const blockG = s('g', { class: 'slider-block' }, svgEl);
    s('rect', { x: 30, y: 14, width: 50, height: 46, rx: 8, fill: '#c8905a', stroke: NAVYC, 'stroke-width': 5 }, blockG);
    blockG.setAttribute('transform', 'translate(0,262)');
    const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    let surf = opts.surface || 'wood';
    function drawSurface() {
      surfG.innerHTML = ''; const S = SURF[surf]; s('rect', { x: 20, y: 322, width: 770, height: 70, rx: 6, fill: S.fill, stroke: NAVYC, 'stroke-width': 5 }, surfG);
      for (let i = 0; i < 26; i++) { const x = 40 + i * 29; if (surf === 'ice') s('line', { x1: x, y1: 336 + (i % 3) * 10, x2: x + 22, y2: 330 + (i % 3) * 10, stroke: S.line, 'stroke-width': 3, 'stroke-linecap': 'round' }, surfG); else if (surf === 'wood') s('line', { x1: x, y1: 322, x2: x, y2: 392, stroke: S.line, 'stroke-width': 2 }, surfG); else s('circle', { cx: x + (i % 2) * 9, cy: 340 + (i % 4) * 12, r: surf === 'sand' ? 3 : 4, fill: S.line }, surfG); }
      for (let m = 0; m <= 18; m += 2) { const x = 55 + m * 40; s('line', { x1: x, y1: 396, x2: x, y2: 408, stroke: '#cfd8f5', 'stroke-width': 3 }, surfG); stext(surfG, x, 418, m + (m === 18 ? ' m' : ''), 'small'); }
      stext(surfG, 405, 60, 'Surface: ' + S.label, 'big');
    }
    function reset() { dynG.innerHTML = ''; blockG.style.transition = 'none'; blockG.style.transform = 'translate(0px,262px)'; blockG.setAttribute('transform', ''); blockG.style.transform = 'translate(0px,262px)'; }
    const api = {
      wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { },
      setSurface(k) { surf = k; drawSurface(); reset(); read.innerHTML = 'Pick a push, then press Push!'; },
      run(push, cb) {
        reset(); const d = slideDist(surf, push); const px = Math.min(d, 18.2) * 40;
        arrow(dynG, 40, 40 + push * 34, 245, '#ffd23f', 12); stext(dynG, 40 + push * 17, 215, PUSHES[push] + ' push', 'small');
        const dur = 0.5 + Math.min(d, 18) * 0.11;
        later(() => { dynG.innerHTML = ''; blockG.style.transition = 'transform ' + dur + 's cubic-bezier(.1,.7,.3,1)'; blockG.style.transform = 'translate(' + px + 'px,262px)'; }, 350 * SPEED);
        later(() => { const fx = 55 + d * 40 + 25; s('line', { x1: fx, y1: 300, x2: fx, y2: 322, stroke: '#ff3b3b', 'stroke-width': 4 }, dynG); stext(dynG, Math.min(fx, 740), 252, d + ' m', 'big'); read.innerHTML = 'The block slid <b>' + d + ' m</b> on ' + SURF[surf].label + ' with a ' + PUSHES[push] + ' push.'; if (cb) cb(d); }, (350 + dur * 1000 + 150) * SPEED);
        return d;
      }
    };
    drawSurface(); reset(); read.innerHTML = 'Pick a surface and a push, then press Push!'; return api;
  }

  /* ---- 5. Heavy haul: the same pull on carts with different mass ---- */
  const haulDist = (blocks, force) => +Math.min(12, 0.4 * force / blocks).toFixed(1);
  function makeHaulScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'A cart with weights on a track. A ruler shows how far a pull moves it.'); const svgEl = b.svgEl;
    s('rect', { x: 20, y: 322, width: 770, height: 40, rx: 6, fill: '#5a6a90', stroke: NAVYC, 'stroke-width': 5 }, svgEl);
    for (let m = 0; m <= 12; m += 2) { const x = 60 + m * 58; s('line', { x1: x, y1: 366, x2: x, y2: 380, stroke: '#cfd8f5', 'stroke-width': 3 }, svgEl); stext(svgEl, x, 400, m + (m === 12 ? ' m' : ''), 'small'); }
    if (opts.target) { const tx = 60 + opts.target * 58; s('line', { x1: tx, y1: 190, x2: tx, y2: 322, stroke: '#7fe3b0', 'stroke-width': 5, 'stroke-dasharray': '10 8' }, svgEl); stext(svgEl, tx, 178, 'finish ' + opts.target + ' m', 'small'); }
    const dyn = s('g', {}, svgEl); const cartG = s('g', {}, svgEl); const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    let blocks = opts.blocks || 2, force = opts.force || 12;
    function drawCart() {
      cartG.innerHTML = ''; cartG.style.transition = 'none'; cartG.style.transform = 'translate(0px,0px)';
      const x = 60; s('rect', { x: x - 56, y: 290, width: 112, height: 22, rx: 6, fill: '#4aa8ff', stroke: NAVYC, 'stroke-width': 5 }, cartG);
      [-32, 32].forEach(o => { s('circle', { cx: x + o, cy: 309, r: 13, fill: '#2b3566', stroke: NAVYC, 'stroke-width': 4 }, cartG); });
      for (let i = 0; i < blocks; i++) { const col = i % 3, row = Math.floor(i / 3); s('rect', { x: x - 50 + col * 34, y: 262 - row * 30, width: 30, height: 28, rx: 4, fill: '#9aa6c8', stroke: NAVYC, 'stroke-width': 3 }, cartG); stext(cartG, x - 35 + col * 34, 283 - row * 30, '1', 'small dark'); }
      dyn.innerHTML = ''; arrow(dyn, x + 60, x + 60 + force * 5.5, 300, '#ffd23f', 12); stext(dyn, x + 60 + force * 2.75, 262, force + ' N pull', 'big');
    }
    const api = {
      wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { },
      set(bl, f) { blocks = bl; force = f; drawCart(); read.innerHTML = 'Load: <b>' + blocks + ' kg</b> &nbsp;|&nbsp; Pull: <b>' + force + ' N</b>'; },
      run(cb) {
        const d = haulDist(blocks, force); drawCart(); const dur = 0.7 + d * 0.18;
        later(() => { dyn.innerHTML = ''; cartG.style.transition = 'transform ' + dur + 's ease-in'; cartG.style.transform = 'translate(' + (d * 58) + 'px,0px)'; }, 300 * SPEED);
        later(() => { const fx = 60 + d * 58; s('line', { x1: fx, y1: 330, x2: fx, y2: 366, stroke: '#ff3b3b', 'stroke-width': 4 }, dyn); stext(dyn, fx, 346 + 0, '', 'small'); stext(dyn, Math.min(fx, 740), 212, d + ' m', 'big'); read.innerHTML = 'Load <b>' + blocks + ' kg</b>, pull <b>' + force + ' N</b>: the cart moved <b>' + d + ' m</b>.'; if (cb) cb(d); }, (300 + dur * 1000 + 150) * SPEED);
        return d;
      }
    };
    api.set(blocks, force); return api;
  }

  /* ---- 6. Bumper cars: a moving car hits a car at rest ---- */
  function bumper(v, mB) { const vB = 2 * v / (1 + mB), vA = v * (1 - mB) / (1 + mB); return { vA: +vA.toFixed(2), vB: +vB.toFixed(2), dB: +(0.5 * vB * vB).toFixed(1), dA: +(0.5 * vA * vA).toFixed(1), eA0: 0.5 * v * v, eA1: 0.5 * vA * vA, eB1: 0.5 * mB * vB * vB }; }
  function makeBumperScene(container, opts) {
    opts = opts || {};
    const b = baseScene(container, 'A moving blue car about to hit an orange car at rest. A ruler shows how far the orange car slides.'); const svgEl = b.svgEl;
    s('rect', { x: 20, y: 322, width: 770, height: 40, rx: 6, fill: '#5a6a90', stroke: NAVYC, 'stroke-width': 5 }, svgEl);
    for (let m = 0; m <= 12; m += 2) { const x = 300 + m * 36; if (x > 780) break; s('line', { x1: x, y1: 366, x2: x, y2: 380, stroke: '#cfd8f5', 'stroke-width': 3 }, svgEl); stext(svgEl, x, 400, m + (m === 12 ? ' m' : ''), 'small'); }
    if (opts.target) { const tx = 300 + opts.target * 36; s('rect', { x: tx - 22, y: 262, width: 44, height: 56, rx: 6, fill: 'rgba(127,227,176,.35)', stroke: '#7fe3b0', 'stroke-width': 5, 'stroke-dasharray': '9 7' }, svgEl); stext(svgEl, tx, 246, 'target ' + opts.target + ' m', 'small'); }
    const dyn = s('g', {}, svgEl), bars = s('g', {}, svgEl);
    const carA = s('g', {}, svgEl), carB = s('g', {}, svgEl);
    const car = (g, col, w) => { s('rect', { x: -w / 2, y: 280, width: w, height: 32, rx: 10, fill: col, stroke: NAVYC, 'stroke-width': 5 }, g); s('rect', { x: -w / 2 + 10, y: 268, width: w - 24, height: 16, rx: 6, fill: col, stroke: NAVYC, 'stroke-width': 4 }, g); [-w / 3, w / 3].forEach(o => s('circle', { cx: o, cy: 311, r: 11, fill: '#2b3566', stroke: NAVYC, 'stroke-width': 4 }, g)); };
    const read = h('div', 'sky-readout', ''); if (opts.readout !== false) container.appendChild(read);
    let v = opts.speed || 3, mB = opts.mB || 1;
    function bar(x, y, val, col, label) { s('rect', { x, y: 128 - val * 7, width: 34, height: Math.max(2, val * 7), fill: col, stroke: NAVYC, 'stroke-width': 3 }, bars); stext(bars, x + 17, 148, label, 'small'); }
    function draw() {
      carA.style.transition = 'none'; carB.style.transition = 'none'; carA.innerHTML = ''; carB.innerHTML = ''; car(carA, '#2f6fe0', 78); car(carB, '#ff8a1f', 62 + mB * 8);
      carA.style.transform = 'translate(90px,0px)'; carB.style.transform = 'translate(300px,0px)'; dyn.innerHTML = ''; bars.innerHTML = '';
      arrow(dyn, 135, 135 + v * 22, 250, '#ffd23f', 11); stext(dyn, 135 + v * 11, 222, 'launch speed ' + v, 'small');
      stext(carB, 0, 262, 'car B: ' + mB + ' kg', 'small'); stext(bars, 90, 40, 'motion energy', 'small');
      bar(50, 0, 0.5 * v * v, '#2f6fe0', 'A'); bar(104, 0, 0, '#ff8a1f', 'B');
    }
    const api = {
      wrap: b.wrap, svg: svgEl, readout: read, stopFlow() { },
      set(sp, m) { v = sp; mB = m; draw(); read.innerHTML = 'Launch speed: <b>' + v + '</b> &nbsp;|&nbsp; Car B mass: <b>' + mB + ' kg</b>'; },
      run(cb) {
        const R = bumper(v, mB); draw();
        later(() => { carA.style.transition = 'transform .5s ease-in'; carA.style.transform = 'translate(' + (300 - 80) + 'px,0px)'; }, 250 * SPEED);
        later(() => {
          carA.style.transition = 'transform ' + (0.6 + R.dA * 0.1) + 's ease-out'; carA.style.transform = 'translate(' + (220 + (R.vA >= 0 ? R.dA * 36 : -R.dA * 36)) + 'px,0px)';
          carB.style.transition = 'transform ' + (0.7 + R.dB * 0.12) + 's cubic-bezier(.1,.7,.3,1)'; carB.style.transform = 'translate(' + (300 + R.dB * 36) + 'px,0px)';
          bars.innerHTML = ''; stext(bars, 90, 40, 'motion energy', 'small'); const sc = 1; bar(50, 0, R.eA1 * sc, '#2f6fe0', 'A'); bar(104, 0, R.eB1 * sc, '#ff8a1f', 'B');
        }, 850 * SPEED);
        later(() => { const fx = 300 + R.dB * 36; s('line', { x1: fx, y1: 330, x2: fx, y2: 366, stroke: '#ff3b3b', 'stroke-width': 4 }, dyn); stext(dyn, Math.min(fx, 720), 214, 'B slid ' + R.dB + ' m', 'big'); read.innerHTML = 'Speed <b>' + v + '</b>, car B <b>' + mB + ' kg</b>: car B slid <b>' + R.dB + ' m</b>.' + (R.vA === 0 ? ' Car A stopped. All its motion energy passed to car B!' : R.vA < 0 ? ' Car A bounced back.' : ''); if (cb) cb(R); }, (850 + (0.7 + R.dB * 0.12) * 1000 + 150) * SPEED);
        return R;
      }
    };
    api.set(v, mB); return api;
  }

  /* =====================================================================
     TASK RUNNERS (shared by every level)
     ===================================================================== */
  // explore a scene with a slider, then answer questions about what you saw
  function exploreTask(ctx, cfg) {
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: null, intro: cfg.intro, tip: cfg.tip });
    const sc = cfg.build(T.body); activeBoards.push(sc); if (sc.wrap) sc.wrap.classList.add('explore');
    const sr = h('div', 'slider-row', '<span>' + cfg.left + '</span><input type="range" min="' + cfg.min + '" max="' + cfg.max + '" step="' + cfg.step + '" value="' + cfg.value + '" aria-label="' + cfg.aria + '"><span>' + cfg.right + '</span>'); T.body.appendChild(sr);
    const inp = sr.querySelector('input'); let lo = +cfg.value, hi = +cfg.value, asked = false; sc.set(+cfg.value);
    inp.addEventListener('input', () => { const v = +inp.value; sc.set(v); lo = Math.min(lo, v); hi = Math.max(hi, v); if (!asked && hi - lo >= cfg.range) { asked = true; later(questions, 700 * SPEED); } });
    say(cfg.start || 'Slide it back and forth and watch what changes!', 'wave');
    function questions() {
      sr.remove(); const list = cfg.questions(state.mode); let i = 0;
      (function next() {
        const old = T.body.querySelector('.choices'); if (old) old.remove(); const q = list[i]; if (q.pre) q.pre(sc);
        askChoice(T.body, { prompt: q.prompt, options: q.options, hint1: q.hint1, hint2: q.hint2, onGood: () => { say(q.done, 'cheer', 'good'); i++; if (i >= list.length) finishTask(ctx); else waitNext('Next question', next); } });
      })();
    }
  }
  // a run of quick questions, each with its own picture
  function quizTask(ctx, cfg) {
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: null, intro: cfg.intro, tip: cfg.tip });
    const rounds = cfg.rounds(state.mode); let i = 0;
    (function next() {
      T.body.innerHTML = ''; stopBoards(); const r = rounds[i]; if (r.build) { const sc = r.build(T.body); if (sc) activeBoards.push(sc); }
      askChoice(T.body, { prompt: (rounds.length > 1 ? 'Question ' + (i + 1) + ' of ' + rounds.length + ': ' : '') + r.prompt, options: r.options, hint1: r.hint1, hint2: r.hint2, onGood: () => { say(r.done, 'cheer', 'good'); i++; if (i >= rounds.length) finishTask(ctx); else waitNext('Next question', next); } });
    })();
  }
  // plain multiple choice (no picture)
  function questionsTask(ctx, cfg) {
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: null, intro: cfg.intro, tip: cfg.tip });
    const list = cfg.questions(state.mode); let i = 0;
    if (cfg.build) { const sc = cfg.build(T.body); if (sc) activeBoards.push(sc); }
    (function next() {
      const old = T.body.querySelector('.choices'); if (old) old.remove(); const q = list[i]; if (q.pre && cfg.scene) q.pre(cfg.scene);
      askChoice(T.body, { prompt: q.prompt, options: q.options, hint1: q.hint1, hint2: q.hint2, onGood: () => { say(q.done, 'cheer', 'good'); i++; if (i >= list.length) finishTask(ctx); else waitNext('Next question', next); } });
    })();
  }
  // put items in order (slots 1..n)
  function orderTask(ctx, cfg) {
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: 'Check', intro: cfg.intro, tip: cfg.tip });
    const items = cfg.items(state.mode), names = items.map(x => x.id); const value = new Array(items.length).fill(null), slotEls = [], chips = {}; let sel = null;
    const slots = h('div', 'rb-slots'), bank = h('div', 'word-bank'); T.body.append(slots, bank);
    const byId = {}; items.forEach(x => { byId[x.id] = x; });
    for (let i = 0; i < items.length; i++) { const sl = h('div', 'rbslot orderslot', '<span class="rbn">' + (i + 1) + '</span><div class="rbfill"></div>'); sl.tabIndex = 0; sl.setAttribute('role', 'button'); sl.setAttribute('aria-label', 'Place number ' + (i + 1)); slots.appendChild(sl); slotEls.push(sl); }
    const fillSlot = (i, c) => { const f = slotEls[i].querySelector('.rbfill'); slotEls[i].classList.remove('right', 'wrong'); if (c) { f.innerHTML = (byId[c].icon || '') + '<span>' + byId[c].label + '</span>'; slotEls[i].classList.add('filled'); } else { f.innerHTML = ''; slotEls[i].classList.remove('filled'); } };
    function put(i, c) { const prev = value[i]; if (prev && chips[prev]) chips[prev].classList.remove('used'); const was = value.indexOf(c); if (was >= 0) { value[was] = null; fillSlot(was, null); } value[i] = c; fillSlot(i, c); chips[c].classList.remove('selected', 'glow-hint'); chips[c].classList.add('used'); sel = null; Object.values(chips).forEach(x => x.classList.remove('selected')); }
    function clearSlot(i) { const c = value[i]; if (!c) return; chips[c].classList.remove('used'); value[i] = null; fillSlot(i, null); }
    items.forEach(it => {
      const c = h('button', 'chip rb-chip orderchip', (it.icon || '') + '<span>' + it.label + '</span>'); c.type = 'button'; chips[it.id] = c;
      drag(c, () => { Object.values(chips).forEach(x => x.classList.remove('selected')); if (sel === it.id) sel = null; else { sel = it.id; c.classList.add('selected'); } }, (x, y) => { const el = document.elementFromPoint(x, y); const sl = el && el.closest ? el.closest('.rbslot') : null; if (sl) put(slotEls.indexOf(sl), it.id); });
    });
    shuffle(names).forEach(n => bank.appendChild(chips[n]));
    slotEls.forEach((sl, i) => { sl.addEventListener('click', () => { if (sel) put(i, sel); else clearSlot(i); }); sl.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sl.click(); } }); });
    if (state.mode === 'easy' && cfg.easyFirst) { put(0, names[0]); slotEls[0].classList.add('right'); }
    const firstWrong = () => names.findIndex((n, i) => value[i] !== n);
    const lad = ladder([
      () => ({ text: cfg.hint1 }),
      () => { const i = firstWrong(); if (i >= 0) chips[names[i]].classList.add('glow-hint'); return { text: 'The glowing card belongs in the first spot that is not right yet.' }; },
      () => { const i = firstWrong(); if (i >= 0) { put(i, names[i]); slotEls[i].classList.add('right'); } return { text: 'I placed one for you as an example. Now finish the rest!' }; }
    ]);
    T.act.onclick = () => {
      if (value.some(v => !v)) { say('Fill every spot first.', 'think'); return; }
      const bad = names.map((n, i) => value[i] === n ? -1 : i).filter(i => i >= 0);
      slotEls.forEach((sl, i) => { sl.classList.remove('right', 'wrong'); sl.classList.add(bad.indexOf(i) >= 0 ? 'wrong' : 'right'); });
      if (!bad.length) { Object.values(chips).forEach(c => c.classList.add('used')); say(cfg.done, 'cheer', 'good'); finishTask(ctx); }
      else { lad.give('Almost! '); setTimeout(() => bad.forEach(i => { if (value[i] !== names[i]) clearSlot(i); }), 1100); }
    };
  }
  // sort cards into two bins
  function sortTask(ctx, cfg) {
    openTask(ctx, { title: cfg.title, prompt: cfg.prompt, action: 'Check', intro: cfg.intro, tip: cfg.tip });
    const items = cfg.items(state.mode); const sorter = makeSorter({ bins: cfg.bins, items }); T.body.appendChild(sorter.el);
    const lad = ladder([
      () => ({ text: cfg.hint1 }),
      () => { const bad = sorter.wrong(); sorter.glow(bad.slice(0, 1)); return { text: 'The glowing card is in the wrong bin.' }; },
      () => { const bad = sorter.wrong(); if (bad[0]) sorter.autoPlace(bad[0]); return { text: 'I moved one for you. Now check the others!' }; }
    ]);
    T.act.onclick = () => {
      if (!sorter.allPlaced()) { say('Put every card in a bin first.', 'think'); return; }
      const bad = sorter.wrong();
      if (!bad.length) { sorter.lock(); say(cfg.done, 'cheer', 'good'); finishTask(ctx); } else { sorter.mark(bad, 'wrong'); lad.give('Almost! '); setTimeout(() => sorter.bounce(bad), 500); }
    };
  }

  // ask a list of questions one after another, with a Next button between them
  function askSequence(ctx, list, sc) {
    let i = 0;
    (function next() {
      const old = T.body.querySelector('.choices'); if (old) old.remove(); const q = list[i]; if (q.pre && sc) q.pre(sc);
      askChoice(T.body, { prompt: q.prompt, options: q.options, hint1: q.hint1, hint2: q.hint2, onGood: () => { say(q.done, 'cheer', 'good'); i++; if (i >= list.length) finishTask(ctx); else waitNext('Next question', next); } });
    })();
  }
  function connectCfg(vocab, terms, syn, extra) {
    return Object.assign({ vocab, terms, syn, distractors: ['pull down', 'year/orbit', 'moon caused', 'blocked light'], title: 'Make the connections', prompt: 'Connect each science term to its connection phrase. Drag a phrase to a blank, or tap a phrase and then tap a blank. Then press Check.', intro: 'Connect the words you just used!', tip: 'Tip: think about what you just did in the lab.', hint1: 'Think about what you just did in the lab.' }, extra || {});
  }

  /* =====================================================================
     VIRTUAL LAB ENGINE (TEKS 5.7B): question, predict, plan, trials, data, pattern, explain
     Simulations are calibrated to Mystery Lab Issue 6 (car 43/90/137 cm, rocket 80/150/215 cm, disc 26/320 cm).
     ===================================================================== */
  const rndSym = a => (Math.random() * 2 - 1) * a;
  const simRamp = p => Math.max(3, Math.round((47 * p.height - 4) * ({ smooth: 1, carpet: 0.35, felt: 0.2 })[p.surface] * (1 + 0.015 * p.mass) + rndSym(2.4)));
  const simRocket = p => { const q = p.pumps - 5; let d = 80 + 14 * q - 0.05 * q * q; d *= ({ 5: 1.02, 10: 1, 15: 0.97 })[p.straw] || 1; if (p.string === 'yarn') d *= 0.7; d *= Math.pow(0.88, p.clips); return Math.max(5, Math.min(292, Math.round(d + rndSym(3.2)))); };
  const simDisc = p => p.air ? Math.round(320 + rndSym(12)) : Math.round(26 + rndSym(2.4));
  const mean3 = a => a.reduce((x, y) => x + y, 0) / a.length;

  function drawTape(parent, x0, px, maxcm, y) {
    s('rect', { x: x0 - 8, y, width: maxcm * px + 16, height: 28, rx: 4, fill: '#ffd23f', stroke: NAVYC, 'stroke-width': 3 }, parent);
    for (let c = 0; c <= maxcm; c += 10) { const major = c % 50 === 0, x = x0 + c * px; s('line', { x1: x, y1: y, x2: x, y2: y + (major ? 17 : 9), stroke: NAVYC, 'stroke-width': major ? 3 : 2 }, parent); if (major) stext(parent, x, y + 40, String(c), 'small'); }
    stext(parent, x0 + maxcm * px + 4, y + 40, 'cm', 'small', 'start');
  }
  function labMarker(g, x, y0, y1, text) { g.innerHTML = ''; if (x == null) return; s('line', { x1: x, y1: y0, x2: x, y2: y1, stroke: '#ff3b3b', 'stroke-width': 4, 'stroke-dasharray': '6 4' }, g); s('polygon', { points: x + ',' + y1 + ' ' + (x - 8) + ',' + (y1 + 14) + ' ' + (x + 8) + ',' + (y1 + 14), fill: '#ff3b3b' }, g); stext(g, x, y0 - 8, text, 'big'); }

  /* ---- ramp scene ---- */
  function makeRampScene(container) {
    const b = baseScene(container, 'A ramp made from books. A car rolls down it onto the floor next to a tape measure.'); const svgEl = b.svgEl;
    const X0 = 360, PX = 2.0, FY = 300, TAPE = 200;
    const floor = s('rect', { x: 0, y: FY, width: 800, height: 120, fill: '#8a94a8' }, svgEl); s('line', { x1: 0, y1: FY, x2: 800, y2: FY, stroke: NAVYC, 'stroke-width': 4 }, svgEl);
    const gStat = s('g', {}, svgEl); drawTape(svgEl, X0, PX, TAPE, FY + 14); stext(svgEl, X0 - 6, FY + 36, '0', 'small', 'end');
    const gLeg = s('g', {}, svgEl), gCar = s('g', {}, svgEl), gMark = s('g', {}, svgEl);
    let P = null;
    const geom = h_ => { const y1 = FY - 26 * h_ - 10; return { x1: 70, y1, ang: Math.atan2(FY - y1, X0 - 70) * 180 / Math.PI }; };
    const api = {
      wrap: b.wrap, svg: svgEl, stopFlow() { }, tapeMax: TAPE, unit: 'cm',
      setup(p) {
        P = p; floor.setAttribute('fill', ({ smooth: '#8a94a8', carpet: '#c94a5a', felt: '#5fa86a' })[p.surface]); gStat.innerHTML = ''; gLeg.innerHTML = ''; gMark.innerHTML = '';
        const g = geom(p.height); const cols = ['#4aa8ff', '#9a6bff', '#ff6a9a', '#ffb347'];
        for (let i = 0; i < p.height; i++) { s('rect', { x: 60, y: FY - 26 * (i + 1), width: 110, height: 26, rx: 3, fill: cols[i % 4], stroke: NAVYC, 'stroke-width': 3 }, gStat); }
        s('polygon', { points: g.x1 + ',' + g.y1 + ' ' + X0 + ',' + FY + ' ' + X0 + ',' + (FY + 10) + ' ' + g.x1 + ',' + (g.y1 + 10), fill: '#d9a864', stroke: NAVYC, 'stroke-width': 4, 'stroke-linejoin': 'round' }, gStat);
        stext(gStat, 110, FY + 52, p.height + (p.height === 1 ? ' book' : ' books'), 'small');
        gCar.innerHTML = ''; gCar.style.transition = 'none'; const t = 0.14, sx = g.x1 + t * (X0 - g.x1), sy = g.y1 + t * (FY - g.y1);
        s('rect', { x: -31, y: -22, width: 62, height: 16, rx: 6, fill: '#2f6fe0', stroke: NAVYC, 'stroke-width': 4 }, gCar); s('rect', { x: -15, y: -34, width: 30, height: 14, rx: 5, fill: '#cfe6ff', stroke: NAVYC, 'stroke-width': 3 }, gCar);
        [-19, 19].forEach(o => s('circle', { cx: o, cy: -6, r: 7, fill: '#2b3566', stroke: NAVYC, 'stroke-width': 3 }, gCar)); for (let i = 0; i < p.mass; i++) s('rect', { x: -22 + i * 15, y: -46, width: 13, height: 11, rx: 2, fill: '#9aa6c8', stroke: NAVYC, 'stroke-width': 2 }, gCar);
        gCar.style.transform = 'translate(' + sx + 'px,' + sy + 'px) rotate(' + g.ang + 'deg)'; api.reset = () => api.setup(P);
      },
      run(p, d, bad, cb) {
        const g = geom(p.height), fx = X0 + d * PX - 31, dur = 0.7 + d * 0.006;
        later(() => { gCar.style.transition = 'transform .8s cubic-bezier(.5,0,.9,.6)'; gCar.style.transform = 'translate(' + (X0 - 34) + 'px,' + FY + 'px) rotate(0deg)'; }, 100 * SPEED);
        later(() => { gCar.style.transition = 'transform ' + dur + 's cubic-bezier(.1,.7,.3,1)'; gCar.style.transform = 'translate(' + fx + 'px,' + FY + 'px) rotate(0deg)'; }, 950 * SPEED);
        later(() => { if (bad) { s('rect', { x: X0 + d * PX + 2, y: FY - 80, width: 16, height: 80, fill: '#6b4a2a', stroke: NAVYC, 'stroke-width': 3 }, gLeg); stext(gLeg, X0 + d * PX + 10, FY - 96, 'BONK!', 'big'); } if (cb) cb(); }, (950 + dur * 1000 + 150) * SPEED);
      },
      mark(m) { labMarker(gMark, m == null ? null : X0 + m * PX, FY - 70, FY + 8, m + ' cm'); }
    };
    return api;
  }

  /* ---- balloon rocket scene ---- */
  function makeRocketScene(container) {
    const b = baseScene(container, 'A balloon rocket on a string with a tape measure below it'); const svgEl = b.svgEl;
    const X0 = 90, PX = 2.3, SY = 150, TAPE = 290;
    [[40], [780]].forEach(p => { s('line', { x1: p[0], y1: SY - 20, x2: p[0], y2: 300, stroke: '#6b7a99', 'stroke-width': 8, 'stroke-linecap': 'round' }, svgEl); s('rect', { x: p[0] - 26, y: 296, width: 52, height: 10, rx: 4, fill: '#2b3566', stroke: NAVYC, 'stroke-width': 3 }, svgEl); });
    const strLine = s('line', { x1: 40, y1: SY, x2: 780, y2: SY, stroke: '#f2f2f2', 'stroke-width': 3 }, svgEl);
    s('line', { x1: X0, y1: SY - 26, x2: X0, y2: 322, stroke: 'rgba(255,255,255,.5)', 'stroke-width': 3, 'stroke-dasharray': '6 6' }, svgEl); stext(svgEl, X0, SY - 34, 'start', 'small');
    drawTape(svgEl, X0, PX, TAPE, 326); stext(svgEl, X0 - 6, 362, '0', 'small', 'end');
    const gRock = s('g', {}, svgEl), gSnag = s('g', {}, svgEl), gMark = s('g', {}, svgEl); let balloonG = null, P = null, cnt = null;
    const api = {
      wrap: b.wrap, svg: svgEl, stopFlow() { }, tapeMax: TAPE, unit: 'cm',
      setup(p) {
        P = p; gRock.innerHTML = ''; gSnag.innerHTML = ''; gMark.innerHTML = ''; gRock.style.transition = 'none'; gRock.style.transform = 'translate(' + X0 + 'px,0px)';
        strLine.setAttribute('stroke-width', p.string === 'yarn' ? 7 : 3); strLine.setAttribute('stroke', p.string === 'yarn' ? '#d9a0ff' : '#f2f2f2');
        const L = p.straw * 6; s('rect', { x: -L, y: SY - 8, width: L, height: 11, rx: 4, fill: '#bfe6ff', stroke: NAVYC, 'stroke-width': 3 }, gRock);
        balloonG = s('g', { class: 'balloon-g' }, gRock); const rb = 12 + p.pumps * 1.6;
        s('ellipse', { cx: -L / 2, cy: SY + 14 + rb * 0.7, rx: rb, ry: rb * 0.7, fill: '#ff4a3a', stroke: NAVYC, 'stroke-width': 4 }, balloonG); s('polygon', { points: (-L / 2 - rb) + ',' + (SY + 14 + rb * 0.7) + ' ' + (-L / 2 - rb - 12) + ',' + (SY + 8 + rb * 0.7) + ' ' + (-L / 2 - rb - 12) + ',' + (SY + 20 + rb * 0.7), fill: '#ff4a3a', stroke: NAVYC, 'stroke-width': 3 }, balloonG);
        s('line', { x1: -L / 2, y1: SY + 3, x2: -L / 2, y2: SY + 14, stroke: NAVYC, 'stroke-width': 3 }, gRock);
        for (let i = 0; i < p.clips; i++) s('rect', { x: -L / 2 - 14 + i * 14, y: SY + 20 + rb * 1.4, width: 11, height: 14, rx: 2, fill: '#ffb347', stroke: NAVYC, 'stroke-width': 2 }, gRock);
        balloonG.style.transformBox = 'fill-box'; balloonG.style.transformOrigin = 'center'; balloonG.style.transition = 'none'; balloonG.style.transform = 'scale(.4)';
        cnt = stext(gRock, -L / 2, SY - 14, 'pumps: 0', 'small'); api.reset = () => api.setup(P);
      },
      run(p, d, bad, cb) {
        const n = p.pumps; for (let i = 1; i <= n; i++) later(() => { cnt.textContent = 'pumps: ' + i; balloonG.style.transition = 'transform .08s'; balloonG.style.transform = 'scale(' + (0.4 + 0.6 * i / n) + ')'; }, (80 + i * 90) * SPEED);
        const t0 = 80 + n * 90 + 350, dur = 0.7 + d * 0.0045;
        later(() => { cnt.textContent = 'release!'; gRock.style.transition = 'transform ' + dur + 's cubic-bezier(.15,.8,.3,1)'; gRock.style.transform = 'translate(' + (X0 + d * PX) + 'px,0px)'; balloonG.style.transition = 'transform ' + dur + 's ease-out'; balloonG.style.transform = 'scale(.45)'; }, t0 * SPEED);
        later(() => { if (bad) { stext(gSnag, X0 + d * PX + 6, SY - 20, 'SNAG!', 'big'); } cnt.textContent = ''; if (cb) cb(); }, (t0 + dur * 1000 + 150) * SPEED);
      },
      mark(m) { labMarker(gMark, m == null ? null : X0 + m * PX, SY + 60, 326, m + ' cm'); }
    };
    return api;
  }

  /* ---- air-glide disc scene ---- */
  function makeDiscScene(container) {
    const b = baseScene(container, 'A rubber-band launcher pushes a disc along the floor next to a tape measure'); const svgEl = b.svgEl;
    const X0 = 150, PX = 1.6, FY = 290, TAPE = 380;
    s('rect', { x: 0, y: FY, width: 800, height: 130, fill: '#9aa3b5' }, svgEl); s('line', { x1: 0, y1: FY, x2: 800, y2: FY, stroke: NAVYC, 'stroke-width': 4 }, svgEl);
    s('rect', { x: 14, y: FY - 14, width: 120, height: 14, rx: 3, fill: '#d9a864', stroke: NAVYC, 'stroke-width': 4 }, svgEl); [30, 108].forEach(x => s('rect', { x: x - 5, y: FY - 56, width: 10, height: 44, rx: 3, fill: '#d9a864', stroke: NAVYC, 'stroke-width': 3 }, svgEl));
    s('line', { x1: 30, y1: FY - 40, x2: 108, y2: FY - 40, stroke: '#ff9a1f', 'stroke-width': 4 }, svgEl); stext(svgEl, 70, FY - 66, 'rubber band', 'small');
    drawTape(svgEl, X0, PX, TAPE, FY + 14); stext(svgEl, X0 - 6, FY + 56, '0', 'small', 'end');
    const gDisc = s('g', {}, svgEl), gLeg = s('g', {}, svgEl), gMark = s('g', {}, svgEl); let P = null;
    const api = {
      wrap: b.wrap, svg: svgEl, stopFlow() { }, tapeMax: TAPE, unit: 'cm',
      setup(p) {
        P = p; gDisc.innerHTML = ''; gLeg.innerHTML = ''; gMark.innerHTML = ''; gDisc.style.transition = 'none'; gDisc.style.transform = 'translate(' + (X0 - 36) + 'px,' + FY + 'px)';
        const up = p.air ? -7 : 0; s('ellipse', { cx: 0, cy: -9 + up, rx: 36, ry: 9, fill: '#ff4a3a', stroke: NAVYC, 'stroke-width': 4 }, gDisc); s('rect', { x: -6, y: -30 + up, width: 12, height: 16, rx: 3, fill: '#ff4a3a', stroke: NAVYC, 'stroke-width': 3 }, gDisc);
        if (p.air) { s('circle', { cx: 0, cy: -48, r: 15, fill: '#ff8a8a', stroke: NAVYC, 'stroke-width': 3 }, gDisc); [[-26, 6], [0, 7], [26, 6]].forEach(a => s('polygon', { points: a[0] + ',2 ' + (a[0] - 6) + ',-6 ' + (a[0] + 6) + ',-6', fill: '#4ac0ff' }, gDisc)); }
        api.reset = () => api.setup(P);
      },
      run(p, d, bad, cb) {
        const fx = X0 + d * PX - 36, dur = 0.5 + d * 0.004;
        later(() => { gDisc.style.transition = 'transform ' + dur + 's cubic-bezier(.1,.8,.3,1)'; gDisc.style.transform = 'translate(' + fx + 'px,' + FY + 'px)'; }, 250 * SPEED);
        later(() => { if (bad) { s('rect', { x: X0 + d * PX + 2, y: FY - 70, width: 14, height: 70, fill: '#6b4a2a', stroke: NAVYC, 'stroke-width': 3 }, gLeg); stext(gLeg, X0 + d * PX + 8, FY - 84, 'BONK!', 'big'); } if (cb) cb(); }, (250 + dur * 1000 + 150) * SPEED);
      },
      mark(m) { labMarker(gMark, m == null ? null : X0 + m * PX, FY - 66, FY + 8, m + ' cm'); }
    };
    return api;
  }

  /* ---- small bar chart (used for graphs and data reading) ---- */
  function chartSvg(values, labels, ymax) {
    const n = values.length, W = 300, H = 190, bw = Math.min(54, 200 / n), gap = (230 - bw * n) / (n + 1), cols = ['#4aa8ff', '#ff9a3c', '#ff5a6a', '#7fe3b0'];
    let out = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Bar graph"><rect width="' + W + '" height="' + H + '" rx="8" fill="#fff"/><line x1="40" y1="20" x2="40" y2="150" stroke="#0b1736" stroke-width="3"/><line x1="40" y1="150" x2="290" y2="150" stroke="#0b1736" stroke-width="3"/>';
    values.forEach((v, i) => { const hgt = Math.max(2, 130 * v / ymax), x = 50 + gap + i * (bw + gap); out += '<rect x="' + x + '" y="' + (150 - hgt) + '" width="' + bw + '" height="' + hgt + '" fill="' + cols[i % 4] + '" stroke="#0b1736" stroke-width="2"/><text x="' + (x + bw / 2) + '" y="' + (146 - hgt) + '" text-anchor="middle" font-size="13" font-weight="700" fill="#0b1736" font-family="Arial">' + Math.round(v) + '</text><text x="' + (x + bw / 2) + '" y="168" text-anchor="middle" font-size="11" fill="#0b1736" font-family="Arial">' + labels[i] + '</text>'; });
    return out + '</svg>';
  }

  /* ---- lab definitions ---- */
  const lvl = (arr, fmt) => arr.map(v => ({ v, label: fmt(v) }));
  const LABS = {
    ramp: {
      id: 'ramp', title: 'Ramp Lab', object: 'car', make: makeRampScene, sim: simRamp, defaults: { height: 2, surface: 'smooth', mass: 0 },
      factors: [{ key: 'height', label: 'the number of books (ramp height)' }, { key: 'surface', label: 'the floor surface' }, { key: 'mass', label: 'the weight on the car' }, { key: 'car', label: 'the car' }, { key: 'board', label: 'the ramp board' }, { key: 'release', label: 'how we let go (no pushing)' }],
      measure: ['how far the car rolls', 'how many books are in the stack', 'the color of the car'], badQ: ['Which car is the coolest?', 'Do ramps like cars?'],
      variables: {
        height: { factor: 'height', param: 'height', noun: 'ramp height', levels: lvl([1, 2, 3], v => v + (v === 1 ? ' book' : ' books')), levels4: lvl([1, 2, 3, 4], v => v + (v === 1 ? ' book' : ' books')), numeric: true, next: { v: 4, label: '4 books' }, question: 'How does ramp height affect how far the car rolls?',
          predictions: ['A taller ramp makes the car roll farther.', 'The height will not matter.', 'A taller ramp makes the car roll less far.'], reason: { good: 'A taller ramp means a bigger force pulls the car down the slope, so its motion changes more.', bad: ['The car gets heavier on a taller ramp.', 'The floor gets slippery on a taller ramp.'] } },
        surface: { factor: 'surface', param: 'surface', noun: 'floor surface', levels: [{ v: 'smooth', label: 'smooth floor' }, { v: 'carpet', label: 'carpet' }, { v: 'felt', label: 'felt' }], question: 'How does the floor surface affect how far the car rolls?',
          predictions: ['The car rolls farthest on the smooth floor.', 'The surface will not matter.', 'The car rolls farthest on the felt.'], reason: { good: 'A rough surface rubs more, so there is more friction and the same force causes less change in motion.', bad: ['A rough surface pushes the car forward.', 'The car gets lighter on carpet.'] }, little: false },
        mass: { factor: 'mass', param: 'mass', noun: 'weight on the car', levels: lvl([0, 1, 2], v => v + (v === 1 ? ' weight' : ' weights')), question: 'How does adding weight to the car affect how far the car rolls?',
          predictions: ['A heavier car rolls farther.', 'The weight will not matter much.', 'A heavier car rolls less far.'], reason: { good: 'Gravity pulls harder on a heavier car, but a heavier car is also harder to speed up, so the two effects almost cancel.', bad: ['Weight always makes a car roll much farther.', 'Weight takes away all the friction.'] }, little: true }
      }
    },
    rocket: {
      id: 'rocket', title: 'Balloon Rocket Lab', object: 'rocket', make: makeRocketScene, sim: simRocket, defaults: { pumps: 10, straw: 10, string: 'line', clips: 0 },
      factors: [{ key: 'pumps', label: 'the amount of air (pumps)' }, { key: 'straw', label: 'the straw length' }, { key: 'string', label: 'the string' }, { key: 'clips', label: 'the weight on the rocket' }, { key: 'balloon', label: 'the balloon' }, { key: 'start', label: 'the start spot' }, { key: 'release', label: 'how we release the rocket' }],
      measure: ['how far the rocket travels along the string', 'the color of the balloon', 'how many pumps we use'], badQ: ['Which balloon color is the prettiest?', 'Are balloons fun to pop?'],
      variables: {
        pumps: { factor: 'pumps', param: 'pumps', noun: 'amount of air', levels: lvl([5, 10, 15], v => v + ' pumps'), numeric: true, next: { v: 20, label: '20 pumps' }, question: 'How does the amount of air in the balloon affect how far the rocket travels along the string?',
          predictions: ['More air makes the rocket go farther.', 'The amount of air will not matter.', 'More air makes the rocket go less far.'], reason: { good: 'More air makes a bigger force pushing the rocket forward, so its motion changes more.', bad: ['More air makes the string shorter.', 'More air makes the balloon heavier so it stops.'] } },
        string: { factor: 'string', param: 'string', noun: 'string', levels: [{ v: 'line', label: 'fishing line' }, { v: 'yarn', label: 'yarn' }], question: 'How does the kind of string affect how far the rocket travels?',
          predictions: ['The rocket goes farther on the smooth fishing line.', 'The string will not matter.', 'The rocket goes farther on the yarn.'], reason: { good: 'Rough yarn rubs more, so there is more friction and the same push causes less change in motion.', bad: ['Yarn pushes the rocket forward.', 'Yarn makes the balloon lighter.'] } },
        clips: { factor: 'clips', param: 'clips', noun: 'weight on the rocket', levels: lvl([0, 1, 2], v => v + (v === 1 ? ' clip' : ' clips')), question: 'How does adding weight to the rocket affect how far it travels?',
          predictions: ['A heavier rocket goes less far.', 'The weight will not matter.', 'A heavier rocket goes farther.'], reason: { good: 'A heavier rocket has more mass, so the same push changes its motion less.', bad: ['Weight gives the balloon more air.', 'Weight removes the friction.'] } },
        straw: { factor: 'straw', param: 'straw', noun: 'straw length', levels: lvl([5, 10, 15], v => v + ' cm straw'), question: 'How does the straw length affect how far the rocket travels?',
          predictions: ['A longer straw makes the rocket go farther.', 'The straw length will not matter much.', 'A longer straw makes the rocket go less far.'], reason: { good: 'The straw length changes the push very little, so the motion changes only a little.', bad: ['A longer straw adds a lot of air.', 'A longer straw removes all friction.'] }, little: true }
      }
    },
    disc: {
      id: 'disc', title: 'Air-Glide Disc Lab', object: 'disc', make: makeDiscScene, sim: simDisc, defaults: { air: false },
      factors: [{ key: 'air', label: 'the air cushion (on or off)' }, { key: 'disc', label: 'the disc' }, { key: 'floor', label: 'the floor' }, { key: 'push', label: 'the push (rubber band pulled to the same mark)' }],
      measure: ['how far the disc glides', 'what color the disc is', 'how stretchy the rubber band is'], badQ: ['Is the disc the best toy?', 'Why are discs round?'],
      variables: {
        air: { factor: 'air', param: 'air', noun: 'air cushion', levels: [{ v: false, label: 'no air' }, { v: true, label: 'with air' }], question: 'How does an air cushion affect how far the disc glides?',
          predictions: ['The disc glides much farther with air.', 'The air will not matter.', 'The disc glides less far with air.'], reason: { good: 'The air cushion lifts the disc a tiny bit, so there is less rubbing. That means less friction, so the same push caused a much bigger change in motion.', bad: ['The air pushes the disc forward harder than the rubber band.', 'The air makes the disc heavier.'] } }
      }
    }
  };

  /* ---- the engine ---- */
  function runLab(ctx, cfg, vkey, opts) {
    opts = opts || {}; const V = cfg.variables[vkey], mode = state.mode, easy = mode === 'easy', chal = mode === 'challenge';
    const levels = chal && V.levels4 ? V.levels4 : V.levels, L = levels.length, STEPS = ['Question', 'Predict', 'Plan', 'Trials', 'Data', 'Pattern', 'Explain'];
    openTask(ctx, { title: opts.title || cfg.title, prompt: 'Run a fair test. Follow the seven steps.', action: null, intro: opts.intro || 'Welcome to the lab! Real scientists follow the mission checklist: question, predict, plan, trials, data, pattern, explain.', tip: opts.tip || 'Tip: a fair test changes one thing, measures one thing, and keeps everything else the same.' });
    const strip = h('div', 'lab-steps'); STEPS.forEach((n, i) => strip.appendChild(h('span', 'lab-step', (i + 1) + ' ' + n))); T.body.appendChild(strip);
    const row = h('div', 'build-row lab-row'); T.body.appendChild(row);
    const sc = cfg.make(row); sc.wrap.classList.add('labwrap2'); activeBoards.push(sc);
    const side = h('div', 'lab-side wide'); row.appendChild(side);
    const tw = h('div', 'trial-wrap'); const tb = h('table', 'trial-table lab-data'); tw.appendChild(tb); side.appendChild(tw);
    const panel = h('div', 'lab-panel'); T.body.appendChild(panel);
    const data = levels.map(() => []), avgs = levels.map(() => null); let step = 0, launches = 0, prediction = null;
    const params = lv => Object.assign({}, cfg.defaults, { [V.param]: lv.v });
    const unit = ' cm', cap = s_ => s_.charAt(0).toUpperCase() + s_.slice(1);
    function drawTable() { tb.innerHTML = '<thead><tr><th>' + cap(V.noun) + '</th><th>T1</th><th>T2</th><th>T3</th><th>Avg</th></tr></thead>'; const body = h('tbody'); levels.forEach((lv, i) => { const r = h('tr'); r.appendChild(h('td', 'lvl', lv.label)); for (let k = 0; k < 3; k++) r.appendChild(h('td', null, data[i][k] === undefined ? '' : String(data[i][k]))); r.appendChild(h('td', 'avg', avgs[i] === null ? '' : String(avgs[i]))); body.appendChild(r); }); tb.appendChild(body); }
    const PROMPTS = ['Step 1 of 7, Question: choose a question you can test.', 'Step 2 of 7, Predict: what do you think will happen?', 'Step 3 of 7, Plan: what will you change, measure, and keep the same?', 'Step 4 of 7, Trials: run 3 good trials for each. Launch, measure, record.', 'Step 5 of 7, Data: find the average of each set of trials.', 'Step 6 of 7, Pattern: what do your averages show?', 'Step 7 of 7, Explain: claim, evidence, and reasoning.'];
    function setStep(i) { step = i; Array.from(strip.children).forEach((c, k) => { c.classList.toggle('on', k === i); c.classList.toggle('done', k < i); }); panel.innerHTML = ''; T.act.hidden = true; setPrompt(PROMPTS[i]); row.style.display = i === 2 ? 'none' : ''; sc.wrap.style.display = i >= 4 ? 'none' : ''; if (window.OBH_TEST) window.__obhLab = Object.assign(window.__obhLab || {}, { step: STEPS[i], avgs: () => avgs.slice(), data, levels }); STEP_FN[i](); }
    const nextBtn = label => waitNext(label || 'Next step', () => setStep(step + 1));
    const pickWrongs = (good, bads, n) => [good].concat(shuffle(bads).slice(0, n));
    drawTable(); sc.setup(params(levels[Math.min(1, L - 1)]));

    // 1 QUESTION
    function stepQuestion() {
      if (opts.chosen) { panel.appendChild(h('div', 'lab-card', '<b>Our question:</b> ' + V.question)); say('This is the question we will test. It changes one thing and measures one thing.', 'think'); nextBtn(); return; }
      askChoice(panel, { prompt: 'Which one is a testable question? (A testable question changes ONE thing and measures ONE thing.)', options: [V.question].concat(cfg.badQ), hint1: 'A testable question can be answered by measuring.', hint2: 'It names what we change and what we measure: ' + V.noun + ' and distance.', onGood: () => { say('Yes! "' + V.question + '" changes one thing and measures one thing.', 'cheer', 'good'); nextBtn(); } });
    }
    // 2 PREDICT
    function stepPredict() {
      panel.appendChild(h('p', 'lab-note', 'Make a prediction. A wrong prediction is useful data!'));
      const bx = h('div', 'picks lab-preds'); V.predictions.forEach((t, i) => { const b = h('button', 'pick lab-pred', '<small>' + t + '</small>'); b.type = 'button'; b.addEventListener('click', () => { prediction = i; Array.from(bx.children).forEach(x => x.classList.remove('picked')); b.classList.add('picked'); say('Prediction saved. Now let us plan a fair test to check it.', 'think'); if (!bx.dataset.done) { bx.dataset.done = '1'; nextBtn(); } }); bx.appendChild(b); }); panel.appendChild(bx);
    }
    // 3 PLAN
    function stepPlan() {
      const grid = h('div', 'plan-grid'); const mk = (cls, ttl) => { const c = h('div', 'plan-col ' + cls); c.appendChild(h('b', null, ttl)); grid.appendChild(c); return c; };
      const cChg = mk('chg', 'CHANGE'), cMeas = mk('meas', 'MEASURE'), cSame = mk('same', 'KEEP THE SAME');
      const sel = (arr, cls, good) => { const e = document.createElement('select'); e.className = cls; e.setAttribute('aria-label', cls); const o0 = document.createElement('option'); o0.value = ''; o0.textContent = 'choose...'; e.appendChild(o0); arr.forEach(a => { const o = document.createElement('option'); o.value = a.value; o.textContent = a.label; if (window.OBH_TEST && a.value === good) o.setAttribute('data-good', '1'); e.appendChild(o); }); return e; };
      const chg = sel(shuffle(cfg.factors.map(f => ({ value: f.key, label: f.label }))), 'plan-change', V.factor); const meas = sel(shuffle(cfg.measure.map((m, i) => ({ value: String(i), label: m }))), 'plan-measure', '0'); cChg.appendChild(chg); cMeas.appendChild(meas);
      const checks = cfg.factors.map(f => { const lb = h('label', 'plan-check'); const cb = document.createElement('input'); cb.type = 'checkbox'; cb.value = f.key; cb.className = 'plan-same'; if (window.OBH_TEST && f.key !== V.factor) cb.setAttribute('data-good', '1'); lb.appendChild(cb); lb.appendChild(document.createTextNode(' ' + f.label)); cSame.appendChild(lb); return cb; });
      panel.appendChild(grid); const btn = h('button', 'btn btn-small', 'Check my plan'); btn.type = 'button'; btn.id = 'plan-check'; panel.appendChild(btn);
      const fill = () => { chg.value = V.factor; meas.value = '0'; checks.forEach(cb => { cb.checked = cb.value !== V.factor; }); };
      if (easy) fill();
      let tries = 0; const lad = ladder([() => ({ text: 'A fair test changes one thing, measures one thing, and keeps everything else the same.' }), () => ({ text: 'The question is about ' + V.noun + '. That is what you CHANGE. What you MEASURE is "' + cfg.measure[0] + '".' }), () => { fill(); return { text: 'I filled in a fair plan. Read it, then press Check.' }; }]);
      T.act.hidden = false; T.act.disabled = false; T.act.textContent = 'Need a hint?'; T.act.onclick = () => lad.give('');
      btn.addEventListener('click', () => {
        const same = checks.filter(c => c.checked).map(c => c.value), need = cfg.factors.filter(f => f.key !== V.factor).map(f => f.key);
        if (chg.value !== V.factor) { tries++; lad.give('Not yet. The question is about ' + V.noun + '. '); return; }
        if (meas.value !== '0') { tries++; lad.give('Not yet. What does the question measure? '); return; }
        if (same.indexOf(V.factor) >= 0) { say('You cannot keep the same the thing you are changing. Uncheck it.', 'worried'); return; }
        const missing = need.filter(k => same.indexOf(k) < 0); if (missing.length) { tries++; say('Something else could change the result. ' + (tries >= 2 ? 'You left out: ' + cfg.factors.find(f => f.key === missing[0]).label + '.' : 'Check every part of the system that must stay the same.'), 'think'); return; }
        T.act.hidden = true; say('That is a fair test plan! One change, one measurement, and everything else the same.', 'cheer', 'good'); btn.disabled = true; nextBtn();
      });
    }
    // 4 TRIALS
    function stepTrials() {
      let sel = 0, busy = false, pend = null, msgEl;
      const lv = h('div', 'picks lab-levels'); const chips = levels.map((l, i) => { const b = h('button', 'pick lab-level', '<small></small>'); b.type = 'button'; b.addEventListener('click', () => { if (!busy) { sel = i; sc.setup(params(levels[i])); upd(); } }); lv.appendChild(b); return b; });
      const meas = h('div', 'lab-measure'); meas.hidden = true; meas.innerHTML = '<span>Line the marker up with the FRONT of the ' + cfg.object + '.</span><button type="button" class="btn btn-ghost btn-small" id="lab-minus" aria-label="down one">-1</button><input type="range" id="lab-measure" min="0" max="' + sc.tapeMax + '" step="1" value="0" aria-label="Tape measure marker"><button type="button" class="btn btn-ghost btn-small" id="lab-plus" aria-label="up one">+1</button><button type="button" class="btn btn-small" id="lab-record">Record</button>';
      const dec = h('div', 'lab-measure'); dec.hidden = true; dec.innerHTML = '<span id="lab-decmsg"></span><button type="button" class="btn btn-small" id="lab-count">Count it</button><button type="button" class="btn btn-small" id="lab-redo">Redo it</button>';
      msgEl = h('p', 'lab-note', 'Pick a ' + V.noun + ', then press Launch! You need 3 good trials for each.'); panel.append(msgEl, lv, meas, dec);
      const inp = meas.querySelector('#lab-measure'), minus = meas.querySelector('#lab-minus'), plus = meas.querySelector('#lab-plus'), rec = meas.querySelector('#lab-record');
      const upd = () => { chips.forEach((c, i) => { c.classList.toggle('picked', i === sel); c.querySelector('small').textContent = levels[i].label + ' (' + data[i].length + '/3)'; c.classList.toggle('doneL', data[i].length >= 3); }); };
      const finishTrial = () => { busy = false; pend = null; meas.hidden = true; dec.hidden = true; drawTable(); upd(); sc.setup(params(levels[sel])); if (data.every(a => a.length >= 3)) { T.act.hidden = true; say('All the trials are done! Now look at your data.', 'cheer', 'good'); nextBtn(); } else { T.act.hidden = false; T.act.textContent = 'Launch!'; T.act.onclick = launch; const nx = data.findIndex(a => a.length < 3); if (data[sel].length >= 3) { sel = nx; sc.setup(params(levels[sel])); upd(); } } };
      const setM = v => { v = Math.max(0, Math.min(sc.tapeMax, v)); inp.value = v; sc.mark(v); };
      inp.addEventListener('input', () => setM(+inp.value)); minus.addEventListener('click', () => setM(+inp.value - 1)); plus.addEventListener('click', () => setM(+inp.value + 1));
      let miss = 0;
      rec.addEventListener('click', () => { if (!pend) return; const tol = Math.max(3, Math.round(pend.d * 0.025)), m = +inp.value; if (Math.abs(m - pend.d) <= tol || miss >= 2) { data[sel].push(miss >= 2 && Math.abs(m - pend.d) > tol ? pend.d : m); say('Recorded ' + data[sel][data[sel].length - 1] + unit + '. ' + (data[sel].length < 3 ? 'Run the next trial.' : 'That is 3 trials for ' + levels[sel].label + '.'), 'cheer', 'good'); miss = 0; finishTrial(); } else { miss++; say(miss >= 2 ? 'Close. I will use the exact reading from the marker if you record again.' : 'Line the red marker up with the FRONT of the ' + cfg.object + ' and try again.', 'think'); } });
      dec.querySelector('#lab-count').addEventListener('click', () => { say('That trial does not count! ' + pend.why + ' Redo it.', 'worried'); });
      dec.querySelector('#lab-redo').addEventListener('click', () => { say('Good call. Repeating a trial is part of a fair test.', 'cheer', 'good'); finishTrial(); });
      function launch() {
        if (busy) return; if (data[sel].length >= 3) { say('You already have 3 trials for that one. Pick another.', 'think'); return; }
        busy = true; T.act.hidden = true; launches++; const p = params(levels[sel]); let d = cfg.sim(p); const bad = !easy && (launches === 4 || (chal && launches === 8)); const why = cfg.id === 'rocket' ? 'The balloon snagged on the string.' : cfg.id === 'disc' ? 'The disc hit a chair leg.' : 'The car hit a table leg.';
        if (bad) d = Math.max(4, Math.round(d * 0.62)); pend = { d, bad, why }; if (window.OBH_TEST) window.__obhLab = Object.assign(window.__obhLab || {}, { trueD: d, bad });
        sc.setup(p); sc.run(p, d, bad, () => {
          if (bad) { dec.hidden = false; dec.querySelector('#lab-decmsg').textContent = why + ' Did the test work?'; say(why + ' Should this trial count?', 'worried'); return; }
          if (easy) { sc.mark(d); data[sel].push(d); say('Measured ' + d + unit + '.', 'cheer', 'good'); later(finishTrial, 700 * SPEED); return; }
          meas.hidden = false; miss = 0; setM(0); say('Now measure it. Move the marker to the front of the ' + cfg.object + ', then press Record.', 'think');
        });
      }
      upd(); T.act.hidden = false; T.act.disabled = false; T.act.textContent = 'Launch!'; T.act.onclick = launch;
    }
    // 5 DATA
    function stepData() {
      const compute = i => Math.round(mean3(data[i]));
      if (easy) { levels.forEach((l, i) => { avgs[i] = compute(i); }); drawTable(); panel.appendChild(h('p', 'lab-note', 'The average is the sum of the 3 trials divided by 3. Averages are filled in for you.')); say('Averages: ' + levels.map((l, i) => l.label + ' = ' + avgs[i] + unit).join(', ') + '.', 'cheer', 'good'); nextBtn(); return; }
      panel.appendChild(h('p', 'lab-note', 'Find the average of the 3 trials for each one: add them up, then divide by 3. Round to a whole number.'));
      const ins = levels.map((l, i) => { const lb = h('label', 'lab-avgrow', l.label + ': '); const inp = document.createElement('input'); inp.type = 'text'; inp.inputMode = 'numeric'; inp.className = 'lab-avg'; inp.setAttribute('aria-label', 'Average for ' + l.label); lb.appendChild(inp); lb.appendChild(document.createTextNode(unit)); panel.appendChild(lb); return inp; });
      const btn = h('button', 'btn btn-small', 'Check averages'); btn.type = 'button'; btn.id = 'avg-check'; panel.appendChild(btn); let tries = 0;
      const lad = ladder([() => ({ text: 'Add the three trials for one row, then divide the sum by 3.' }), () => ({ text: 'For ' + levels[0].label + ': ' + data[0].join(' + ') + ' = ' + data[0].reduce((a, b) => a + b, 0) + '. Then divide by 3.' }), () => { ins.forEach((e, i) => { e.value = compute(i); }); return { text: 'I filled in the averages. Press Check.' }; }]);
      T.act.hidden = false; T.act.disabled = false; T.act.textContent = 'Need a hint?'; T.act.onclick = () => lad.give('');
      btn.addEventListener('click', () => { const ok = ins.map((e, i) => Math.abs(+e.value - compute(i)) <= Math.max(1, Math.round(compute(i) * 0.01)) && e.value.trim() !== ''); ins.forEach((e, i) => e.classList.toggle('bad', !ok[i])); if (ok.every(Boolean)) { ins.forEach((e, i) => { avgs[i] = compute(i); }); drawTable(); T.act.hidden = true; btn.disabled = true; say('Right! Those are your averages. Averaging three trials makes the data more trustworthy.', 'cheer', 'good'); nextBtn(); } else { tries++; lad.give('Check the red ones. '); } });
    }
    const hi = () => avgs.indexOf(Math.max(...avgs)), lo = () => avgs.indexOf(Math.min(...avgs)), little = () => (Math.max(...avgs) - Math.min(...avgs)) / Math.max(...avgs) < 0.07;
    // 6 PATTERN
    function stepPattern() {
      const a = levels[hi()].label, b = levels[lo()].label, ms = cfg.measure[0];
      const good = little() ? 'There was only a small change. The ' + V.noun + ' made little difference.' : 'The ' + ms.replace(/^how far /, 'distance ').replace(/^distance the /, 'distance the ') + ' was greatest with ' + a + ' and least with ' + b + '.';
      const wrong1 = little() ? 'The ' + V.noun + ' made a huge difference.' : 'It was greatest with ' + b + ' and least with ' + a + '.', wrong2 = little() ? 'The data went up and down with no numbers.' : 'There was no pattern. All the averages were about the same.';
      askChoice(panel, { prompt: 'Look at your averages. What pattern do you see?', options: [good, wrong1, wrong2], hint1: 'Compare the biggest average with the smallest average.', hint2: 'The biggest average is ' + avgs[hi()] + ' (' + a + '). The smallest is ' + avgs[lo()] + ' (' + b + ').', onGood: () => { say('Yes! ' + good, 'cheer', 'good'); if (easy) { nextBtn(); } else waitNext('Next: graph', graphPick); } });
    }
    function graphPick() {
      panel.innerHTML = ''; const labs = levels.map(l => l.label.replace(' pumps', '').replace(' books', '').replace(' book', '').replace(' weights', '').replace(' weight', '').replace(' clips', '').replace(' clip', '').replace(' cm straw', '').replace('fishing line', 'line').replace('smooth floor', 'smooth').replace('no air', 'none').replace('with air', 'air')), ymax = Math.max(...avgs) * 1.15;
      const rev = avgs.slice().reverse(), shuf = avgs.map((v, i) => avgs[(i + 1) % L]); const opts = [{ key: 'good', vals: avgs }, { key: 'w1', vals: L > 1 ? rev : avgs.map(v => v * 0.5) }, { key: 'w2', vals: shuf }];
      if (JSON.stringify(rev) === JSON.stringify(avgs)) opts[1].vals = avgs.map((v, i) => avgs[(i + 2) % L] * (i % 2 ? 1.4 : 0.6)); if (JSON.stringify(shuf) === JSON.stringify(avgs) || JSON.stringify(shuf) === JSON.stringify(opts[1].vals)) opts[2].vals = avgs.map((v, i) => v * (i % 2 ? 0.45 : 1.3));
      panel.appendChild(h('p', 'lab-note', 'Which graph matches your data table?'));
      const lad = ladder([() => ({ text: 'Compare the bar heights with your averages.' }), () => ({ text: 'The bars should be ' + avgs.join(', ') + ' from left to right.' }), () => { const g = pr.find('good'); if (g) g.classList.add('glow-hint'); return { text: 'Look at the glowing graph.' }; }]); let locked = false;
      const pr = pickRow(shuffle(opts.map(o => ({ key: o.key, html: chartSvg(o.vals, labs, ymax), label: 'graph' }))), (k, bt) => { if (locked) return; if (k === 'good') { locked = true; pr.lock(); bt.classList.add('right'); say('Yes! That graph matches your averages.', 'cheer', 'good'); nextBtn(); } else { bt.classList.add('wrong'); lad.give('Not quite. '); } });
      pr.el.classList.add('graph-picks'); panel.appendChild(pr.el);
    }
    // 7 EXPLAIN (claim, evidence, reasoning)
    function stepExplain() {
      const a = levels[hi()], b = levels[lo()], seq = [];
      const claimGood = little() ? 'The ' + V.noun + ' made only a small difference.' : 'The ' + V.noun + ' changes ' + cfg.measure[0].replace(/^how /, '') + '. It went farthest with ' + a.label + '.';
      seq.push({ t: 'CLAIM: What does your test show?', o: [claimGood, 'The ' + V.noun + ' made no difference at all.', 'It went farthest with ' + b.label + '.'].slice(0, little() ? 3 : 3), h1: 'Look at your pattern.', h2: 'Use your averages.', d: 'Good claim. It answers the question.' });
      const evGood = little() ? 'With ' + a.label + ' the average was ' + avgs[hi()] + unit + ' and with ' + b.label + ' it was ' + avgs[lo()] + unit + ', only a small difference.' : 'With ' + b.label + ' the average was ' + avgs[lo()] + unit + ', and with ' + a.label + ' it was ' + avgs[hi()] + unit + '.';
      seq.push({ t: 'EVIDENCE: Which numbers from YOUR data support the claim?', o: [evGood, 'With ' + a.label + ' the average was ' + avgs[lo()] + unit + ', and with ' + b.label + ' it was ' + avgs[hi()] + unit + '.', 'The ' + cfg.object + ' was blue.'], h1: 'Evidence is data from your table.', h2: 'The biggest average was ' + avgs[hi()] + unit + ' and the smallest was ' + avgs[lo()] + unit + '.', d: 'That is evidence: real numbers from your investigation.' });
      if (!easy || true) { const good = V.reason.good; seq.push({ t: 'REASONING: Why did this happen? Use force and motion.', o: [good].concat(V.reason.bad), h1: 'Think about forces, friction, and mass.', h2: 'What force was different?', d: 'That connects the pattern to force and motion.' }); }
      if (chal && V.numeric) { const slope = (avgs[L - 1] - avgs[0]) / (levels[L - 1].v - levels[0].v), pred = Math.round(avgs[L - 1] + slope * (V.next.v - levels[L - 1].v)); seq.push({ t: 'USE YOUR PATTERN: About how far would you predict for ' + V.next.label + '?', o: [String(pred) + unit, String(Math.round(pred * 0.5)) + unit, String(Math.round(pred * 1.6)) + unit], h1: 'Look at how much the average grows each step.', h2: 'Each step adds about ' + Math.round(slope * (levels[1].v - levels[0].v)) + unit + '.', d: 'Great! A pattern lets you predict.' }); }
      let i = 0; (function next() { panel.innerHTML = ''; const q = seq[i]; askChoice(panel, { prompt: q.t, options: q.o, hint1: q.h1, hint2: q.h2, onGood: () => { say(q.d, 'cheer', 'good'); i++; if (i >= seq.length) finishTask(ctx); else waitNext('Next', next); } }); })();
    }
    const STEP_FN = [stepQuestion, stepPredict, stepPlan, stepTrials, stepData, stepPattern, stepExplain];
    setStep(0);
  }

  /* =====================================================================
     LEVEL 1: BRIEFING ROOM (the mission checklist, systems, testable questions, variables)
     ===================================================================== */
  function taskChecklist(ctx) {
    orderTask(ctx, { title: 'The mission checklist', prompt: 'Every mission follows the same seven steps. Put them in order. Then press Check.', intro: 'Welcome to the Briefing Room! Real scientists follow a checklist, just like Mission Control in Mystery Lab Issue 6.', tip: 'Tip: you start by asking a question and finish by explaining.',
      easyFirst: true, hint1: 'Start with the question. Then predict. You explain at the very end.', done: 'Perfect! Question, predict, plan, trials, data, pattern, explain.',
      items: () => ['Question', 'Predict', 'Plan', 'Trials', 'Data', 'Pattern', 'Explain'].map(x => ({ id: x.toLowerCase(), label: x })) });
  }
  function taskSystemSort(ctx) {
    sortTask(ctx, { title: 'Build a system', prompt: 'A system is a group of parts that work together. Drag each card to the right bin. Then press Check.', intro: 'A car on a ramp is a system. Which things are part of it?', tip: 'Tip: if it affects how the car rolls, it is part of the system.',
      bins: [{ id: 'in', title: 'Part of the system', sub: 'works together' }, { id: 'out', title: 'Not part of it', sub: 'does not matter' }],
      items: mode => { const all = [{ id: 'a', label: 'the car', bin: 'in' }, { id: 'b', label: 'the ramp board', bin: 'in' }, { id: 'c', label: 'the floor', bin: 'in' }, { id: 'd', label: 'the stack of books', bin: 'in' }, { id: 'e', label: 'your lunch', bin: 'out' }, { id: 'f', label: 'the Moon', bin: 'out' }]; return mode === 'easy' ? all.slice(0, 5) : all; },
      hint1: 'The car, the ramp, the books, and the floor all affect how far the car rolls.', done: 'Right! A car, a ramp, and the floor are a system.' });
  }
  function taskTestable(ctx) {
    quizTask(ctx, { title: 'Testable questions', prompt: 'A testable question changes ONE thing and measures ONE thing.', intro: 'Mission Control says: do not guess, test it! But first you need a testable question.', tip: 'Tip: can you answer it by changing one thing and measuring one thing?',
      rounds: mode => [
        { prompt: 'Which question is testable?', options: ['How does ramp height affect how far a car rolls?', 'Which car is the best?', 'Do ramps like cars?'], hint1: 'Which one names one thing to change and one thing to measure?', hint2: 'Ramp height is what we change. How far the car rolls is what we measure.', done: 'Yes! It changes ramp height and measures distance.' },
        { prompt: 'Which question is testable?', options: ['How does the amount of air in a balloon affect how far a rocket travels?', 'Is the balloon pretty?', 'Why do balloons exist?'], hint1: 'You can measure how far the rocket travels.', hint2: 'Air is what we change. Distance is what we measure.', done: 'Right! We can change the air and measure the distance.' },
        { prompt: 'Which question is testable?', options: ['How does the floor surface affect how far a disc slides?', 'Is sliding fun?', 'What is the best toy?'], hint1: 'Which one can be answered with measurements?', hint2: 'The surface is what we change. The slide distance is what we measure.', done: 'Yes! Surface and distance are testable.' },
        { prompt: 'Which question is NOT testable?', options: ['Which toy is the coolest?', 'How does ramp height affect distance?', 'How does air affect how far a rocket goes?'], hint1: 'Which one cannot be answered by measuring?', hint2: '"Coolest" is an opinion. You cannot measure it.', done: 'Right! An opinion is not testable.' }
      ].slice(0, mode === 'easy' ? 3 : 4) });
  }
  function taskVarConst(ctx) {
    sortTask(ctx, { title: 'Change, measure, or keep the same?', prompt: 'A balloon rocket test: drag each card to the right bin. Then press Check.', intro: 'A fair test has three parts: what you change, what you measure, and what you keep the same.', tip: 'Tip: you change ONE thing, measure ONE thing, and keep the rest the same.',
      bins: [{ id: 'chg', title: 'Change', sub: 'the variable' }, { id: 'meas', title: 'Measure', sub: 'the data' }, { id: 'same', title: 'Keep the same', sub: 'constants' }],
      items: mode => { const all = [{ id: 'a', label: 'pumps of air', bin: 'chg' }, { id: 'b', label: 'distance the rocket travels', bin: 'meas' }, { id: 'c', label: 'the same balloon', bin: 'same' }, { id: 'd', label: 'the same string', bin: 'same' }, { id: 'e', label: 'the same start spot', bin: 'same' }]; return mode === 'easy' ? all.slice(0, 4) : all; },
      hint1: 'The question is about the amount of air. That is what you change. The distance is what you measure.', done: 'Perfect! One variable, one measurement, and everything else is a constant.' });
  }
  const CONNECT_T1 = connectCfg({
    system: { term: 'system', phrase: 'parts working together', syn: ['a group of parts that work together', 'car, ramp, and floor'], wrong: ['what is tested/changed', 'stays the same'] },
    variable: { term: 'variable', phrase: 'what is tested/changed', syn: ['the one thing you change', 'what we change on purpose'], wrong: ['stays the same', 'proof'] },
    constant: { term: 'constant', phrase: 'stays the same', syn: ['kept the same on purpose', 'not changed'], wrong: ['what is tested/changed', 'proof'] },
    trial: { term: 'trial', phrase: 'one round of a test', syn: ['one try', 'run it once'], wrong: ['measurements', 'stays the same'] },
    fair: { term: 'fair test', phrase: 'change one thing', syn: ['one change, keep the rest the same', 'only one variable'], wrong: ['stays the same', 'proof'] }
  }, { easy: ['variable', 'constant'], standard: ['system', 'variable', 'constant', 'fair'], challenge: ['system', 'variable', 'constant', 'trial', 'fair'] }, { easy: ['variable'], standard: ['variable', 'constant', 'fair'], challenge: ['system', 'variable', 'constant', 'trial'] }, { distractors: ['proof', 'push/pull', 'pull down'], tip: 'Tip: think about what you change and what you keep the same.', hint1: 'Think about what you change and what you keep the same.' });
  function taskConnectT1(ctx) { connectRun(ctx, CONNECT_T1); }

  /* =====================================================================
     LEVELS 2 TO 4: THE THREE VIRTUAL LABS (ramp, balloon rocket, air-glide disc)
     ===================================================================== */
  function taskRampLab(ctx) { runLab(ctx, LABS.ramp, 'height', { title: 'Mission 1: the car on a ramp', intro: 'Coach Torque says: test how ramp height affects how far the car rolls. Follow the seven steps!' }); }
  function taskRocketLab(ctx) { runLab(ctx, LABS.rocket, 'pumps', { title: 'Mission 2: the balloon rocket', intro: 'Coach Torque says: test how the amount of air affects how far the rocket travels along the string.' }); }
  function taskDiscLab(ctx) { runLab(ctx, LABS.disc, 'air', { title: 'Mission 3: the air-glide disc', intro: 'Coach Torque says: the heavy crate needs to slide farther. Test how an air cushion affects how far the disc glides.' }); }
  const CONNECT_T2 = connectCfg({
    variable: { term: 'variable', phrase: 'what is tested/changed', syn: ['the one thing you change', 'what we change on purpose'], wrong: ['stays the same', 'proof'] },
    constant: { term: 'constant', phrase: 'stays the same', syn: ['kept the same on purpose', 'not changed'], wrong: ['what is tested/changed', 'proof'] },
    data: { term: 'data', phrase: 'measurements', syn: ['numbers we collect', 'observations'], wrong: ['one round of a test', 'proof'] },
    evidence: { term: 'evidence', phrase: 'proof', syn: ['data that shows it', 'what you observed'], wrong: ['push/pull', 'balance/stuff'] },
    pattern: { term: 'pattern', phrase: 'repeating', syn: ['happens again and again', 'repeats'], wrong: ['proof', 'pull down'] }
  }, { easy: ['variable', 'data'], standard: ['variable', 'constant', 'data', 'evidence'], challenge: ['variable', 'constant', 'data', 'evidence', 'pattern'] }, { easy: ['variable'], standard: ['variable', 'data', 'evidence'], challenge: ['variable', 'constant', 'data', 'evidence'] }, { distractors: ['push/pull', 'pull down', 'slows/stops motion'], tip: 'Tip: think about your ramp investigation.', hint1: 'Think about your ramp investigation.' });
  function taskConnectT2(ctx) { connectRun(ctx, CONNECT_T2); }
  const CONNECT_T3 = connectCfg({
    trial: { term: 'trial', phrase: 'one round of a test', syn: ['one try', 'run it once'], wrong: ['measurements', 'stays the same'] },
    force: { term: 'force', phrase: 'push/pull', syn: ['a push or a pull', 'changes motion'], wrong: ['slows/stops motion', 'measures force'] },
    motion: { term: 'motion', phrase: 'change in position', syn: ['moving from one place to another', 'position changes over time'], wrong: ['no motion', 'slows/stops motion'] },
    pattern: { term: 'pattern', phrase: 'repeating', syn: ['happens again and again', 'repeats'], wrong: ['proof', 'pull down'] }
  }, { easy: ['trial', 'force'], standard: ['trial', 'force', 'motion', 'pattern'], challenge: ['trial', 'force', 'motion', 'pattern'] }, { easy: ['trial'], standard: ['trial', 'force', 'motion'], challenge: ['trial', 'force', 'motion', 'pattern'] }, { distractors: ['proof', 'slows/stops motion', 'balance/stuff'], tip: 'Tip: think about the balloon rocket.', hint1: 'Think about the balloon rocket.' });
  function taskConnectT3(ctx) { connectRun(ctx, CONNECT_T3); }
  const CONNECT_T4 = connectCfg({
    friction: { term: 'friction', phrase: 'slows/stops motion', syn: ['rubbing force', 'works against motion'], wrong: ['causes motion', 'push/pull'] },
    force: { term: 'force', phrase: 'push/pull', syn: ['a push or a pull', 'changes motion'], wrong: ['slows/stops motion', 'measures force'] },
    evidence: { term: 'evidence', phrase: 'proof', syn: ['data that shows it', 'what you observed'], wrong: ['push/pull', 'balance/stuff'] },
    constant: { term: 'constant', phrase: 'stays the same', syn: ['kept the same on purpose', 'not changed'], wrong: ['what is tested/changed', 'proof'] }
  }, { easy: ['friction', 'force'], standard: ['friction', 'force', 'evidence', 'constant'], challenge: ['friction', 'force', 'evidence', 'constant'] }, { easy: ['friction'], standard: ['friction', 'force', 'constant'], challenge: ['friction', 'force', 'evidence', 'constant'] }, { distractors: ['causes motion', 'balance/stuff', 'pull down'], tip: 'Tip: think about the air cushion and the disc.', hint1: 'Think about the air cushion and the disc.' });
  function taskConnectT4(ctx) { connectRun(ctx, CONNECT_T4); }

  /* =====================================================================
     LEVEL 5: JUDGES' TABLE (spot the mistake, averages, graphs, fair plans)
     ===================================================================== */
  function taskMistakes(ctx) {
    quizTask(ctx, { title: 'Spot the mistake', prompt: 'Judge Sprocket found a problem with each test. What is it?', intro: 'Welcome to the Judges\' Table! Judge Sprocket checks every test for mistakes.', tip: 'Tip: a fair test changes one thing, measures one thing, and keeps everything else the same.',
      rounds: mode => shuffle([
        { prompt: 'Diego pushes the car at the top of the ramp "to help it go." What is the problem?', options: ['The push adds an extra force, so we cannot tell what the ramp did.', 'Pushing makes the car heavier.', 'There is no problem.'], hint1: 'What is the ramp supposed to be the only thing changing?', hint2: 'A push is an extra force. It changes the result too.', done: 'Right! A push adds an extra force, so we could not tell what the ramp did.' },
        { prompt: 'Diego plans to change the amount of air AND the straw length. What is the problem?', options: ['He changed two things, so he could not tell which one caused the result.', 'Air and straws do not mix.', 'There is no problem.'], hint1: 'How many things did he change?', hint2: 'Change only ONE variable.', done: 'Yes! Change only one thing so you know what caused the result.' },
        { prompt: 'Rocco\'s crew blows the balloon up "as big as it goes" and launches it one time. What is the problem?', options: ['"As big as it goes" cannot be repeated exactly, and one trial can be a fluke.', 'Big balloons are not allowed.', 'There is no problem.'], hint1: 'Could you do the exact same thing again?', hint2: 'Use a measured amount, like pumps, and run three trials.', done: 'Right! Use a measured amount and repeat the trials.' },
        { prompt: 'A team runs only one trial for each ramp height. What is the problem?', options: ['One odd result could trick them. They should run three trials.', 'One trial is plenty.', 'Ramps need three books.'], hint1: 'What if one trial was a weird result?', hint2: 'Repeated trials make the data more trustworthy.', done: 'Yes! Three trials make the data more trustworthy.' },
        { prompt: 'During a trial the car hits a table leg and stops early. What should the team do?', options: ['Say that trial does not count and redo it.', 'Count it anyway.', 'Average it with the other trials.'], hint1: 'Did the test work the way it was planned?', hint2: 'A trial where something went wrong does not count. Redo it.', done: 'Right! That trial does not count, so redo it.' },
        { prompt: 'One student measures from the top of the ramp. Another measures from the bottom. What is the problem?', options: ['They should measure from the same starting place every time.', 'Measuring is not allowed.', 'There is no problem.'], hint1: 'Is the measuring the same each time?', hint2: 'Keep the measuring the same: same start line, same way.', done: 'Yes! Measure the same way every time.' }
      ]).slice(0, mode === 'easy' ? 4 : 6) });
  }
  function avgRound(vals) {
    const avg = Math.round(mean3(vals)), sum = vals.reduce((a, b) => a + b, 0), mx = Math.max(...vals);
    return { prompt: 'A team recorded ' + vals.join(', ') + ' cm. What is the average?', options: [avg + ' cm', sum + ' cm', mx + ' cm'], hint1: 'Add the three numbers, then divide by 3.', hint2: vals.join(' + ') + ' = ' + sum + '. Then ' + sum + ' divided by 3 is about ' + avg + '.', done: 'Yes! The average is ' + avg + ' cm.' };
  }
  function taskAverages(ctx) {
    quizTask(ctx, { title: 'Find the average', prompt: 'Averages make data more trustworthy.', intro: 'Judge Sprocket wants to see the averages.', tip: 'Tip: add the trials, then divide by the number of trials.',
      rounds: mode => [avgRound([42, 44, 43]), avgRound([80, 82, 78]), avgRound([150, 148, 152]), mode === 'challenge' ? { prompt: 'A team recorded 135, 137, 139 cm and a fourth trial of 60 cm that hit a table leg. What average should they report?', options: ['137 cm (the three good trials)', '118 cm (all four trials)', '60 cm'], hint1: 'Which trials counted?', hint2: 'The trial that hit the table leg does not count.', done: 'Right! Leave out the trial that did not count.' } : avgRound([215, 218, 212])].slice(0, mode === 'easy' ? 3 : 4) });
  }
  function taskReadGraph(ctx) {
    const gb = (vals, labs, ymax) => c => { const w = makeWrap(c, 'skywrap explore chart-only'); w.innerHTML = chartSvg(vals, labs, ymax); return { wrap: w, stopFlow() { } }; };
    quizTask(ctx, { title: 'Read the graph', prompt: 'Which statement does the graph support?', intro: 'Graphs show patterns in the data.', tip: 'Tip: compare the heights of the bars.',
      rounds: mode => [
        { build: gb([43, 90, 137], ['1 book', '2 books', '3 books'], 160), prompt: 'Average distance a car rolled for each ramp height. Which statement does the graph support?', options: ['The taller the ramp, the farther the car rolled.', 'The taller the ramp, the less far the car rolled.', 'Ramp height made no difference.'], hint1: 'Do the bars get taller or shorter from left to right?', hint2: 'The bars keep getting taller as the ramp gets taller.', done: 'Yes! A taller ramp gave a longer roll.' },
        { build: gb([80, 150, 215], ['5 pumps', '10 pumps', '15 pumps'], 250), prompt: 'Average distance a balloon rocket traveled. Which statement does the graph support?', options: ['More air made the rocket go farther.', 'More air made the rocket go less far.', 'The amount of air did not matter.'], hint1: 'Compare the first and last bars.', hint2: 'The 15 pumps bar is the tallest.', done: 'Right! More air, farther rocket.' },
        { build: gb([26, 320], ['no air', 'with air'], 360), prompt: 'Average distance an air-glide disc slid. Which statement does the graph support?', options: ['The disc slid much farther with air.', 'The disc slid farther without air.', 'Air made no difference.'], hint1: 'Which bar is taller?', hint2: 'The with air bar is much taller.', done: 'Yes! The air cushion reduced friction, so the disc slid much farther.' },
        { build: gb([78, 80, 79], ['5 cm', '10 cm', '15 cm'], 100), prompt: 'Average distance for three straw lengths. Which statement does the graph support?', options: ['Straw length made only a small difference.', 'A longer straw made the rocket go much farther.', 'A longer straw made the rocket go much less far.'], hint1: 'Are the bars very different in height?', hint2: 'All three bars are almost the same height.', done: 'Right! The bars are about the same, so straw length made little difference.' }
      ].slice(0, mode === 'easy' ? 3 : 4) });
  }
  function taskFairJudge(ctx) {
    quizTask(ctx, { title: 'Which plan is fair?', prompt: 'Choose the fair test.', intro: 'Judge Sprocket shows two plans. Only one is a fair test.', tip: 'Tip: one change, one measurement, everything else the same, and three trials.',
      rounds: mode => [
        { prompt: 'Plan A: Change the ramp height. Keep the car, ramp board, floor, and how we let go the same. Plan B: Change the ramp height and the car. Which plan is fair?', options: ['Plan A is fair.', 'Plan B is fair.', 'Both are fair.'], hint1: 'How many things does each plan change?', hint2: 'Plan B changes two things.', done: 'Yes! Plan A changes only one thing.' },
        { prompt: 'Plan A: Use a new balloon and a different string each time. Plan B: Change the pumps of air. Keep the balloon, straw, string, and start spot the same. Which plan is fair?', options: ['Plan B is fair.', 'Plan A is fair.', 'Both are fair.'], hint1: 'Which plan keeps the rest the same?', hint2: 'Plan A changes many things at once.', done: 'Right! Plan B changes only the air.' },
        { prompt: 'Plan A: Run one trial for each surface. Plan B: Run three trials for each surface and average them. Which plan is better?', options: ['Plan B is better.', 'Plan A is better.', 'They are the same.'], hint1: 'Which plan makes the data more trustworthy?', hint2: 'Repeated trials make data more trustworthy.', done: 'Yes! Three trials and an average are better.' },
        { prompt: 'Plan A: Measure from the same start line every time. Plan B: Measure from wherever the car starts. Which plan is fair?', options: ['Plan A is fair.', 'Plan B is fair.', 'Both are fair.'], hint1: 'Is the measuring the same each time?', hint2: 'Keep the measuring the same.', done: 'Right! Measure the same way every time.' }
      ].slice(0, mode === 'easy' ? 3 : 4) });
  }
  const CONNECT_T5 = connectCfg({
    fair: { term: 'fair test', phrase: 'change one thing', syn: ['one change, keep the rest the same', 'only one variable'], wrong: ['stays the same', 'proof'] },
    variable: { term: 'variable', phrase: 'what is tested/changed', syn: ['the one thing you change', 'what we change on purpose'], wrong: ['stays the same', 'proof'] },
    constant: { term: 'constant', phrase: 'stays the same', syn: ['kept the same on purpose', 'not changed'], wrong: ['what is tested/changed', 'proof'] },
    evidence: { term: 'evidence', phrase: 'proof', syn: ['data that shows it', 'what you observed'], wrong: ['push/pull', 'balance/stuff'] }
  }, { easy: ['fair', 'variable'], standard: ['fair', 'variable', 'constant', 'evidence'], challenge: ['fair', 'variable', 'constant', 'evidence'] }, { easy: ['fair'], standard: ['fair', 'variable', 'constant'], challenge: ['fair', 'variable', 'constant', 'evidence'] }, { distractors: ['push/pull', 'pull down', 'slows/stops motion'], tip: 'Tip: think about what makes a test fair.', hint1: 'Think about what makes a test fair.' });
  function taskConnectT5(ctx) { connectRun(ctx, CONNECT_T5); }

  /* =====================================================================
     LEVEL 6: DERBY DAY (design your own investigation, tune the winners, final round)
     ===================================================================== */
  let derbyChoice = { lab: 'ramp', vkey: 'height' };
  function taskChoose(ctx) {
    openTask(ctx, { title: 'Your Mission Planner', prompt: 'Choose a car on a ramp or a balloon rocket on a string.', action: null, intro: 'Derby Day is here! Now it is YOUR turn. Plan it. Test it. Explain it!', tip: 'Tip: you will change ONE thing and measure how far it goes.' });
    const labBox = h('div', 'picks lab-choose'); const varBox = h('div', 'picks lab-choose'); T.body.append(labBox, varBox); let done = false;
    const labs = [{ id: 'ramp', t: 'Car on a ramp' }, { id: 'rocket', t: 'Balloon rocket on a string' }];
    labs.forEach(l => { const b = h('button', 'pick lab-pick', '<small>' + l.t + '</small>'); b.type = 'button'; b.addEventListener('click', () => { if (done) return; derbyChoice.lab = l.id; Array.from(labBox.children).forEach(x => x.classList.remove('picked')); b.classList.add('picked'); varBox.innerHTML = ''; Object.keys(LABS[l.id].variables).forEach(k => { const v = LABS[l.id].variables[k]; const vb = h('button', 'pick var-pick', '<small>Change the ' + v.noun + '</small>'); vb.type = 'button'; vb.dataset.key = k; vb.addEventListener('click', () => { if (done) return; derbyChoice.vkey = k; Array.from(varBox.children).forEach(x => x.classList.remove('picked')); vb.classList.add('picked'); say('Your question: ' + v.question, 'cheer', 'good'); if (!varBox.dataset.done) { varBox.dataset.done = '1'; waitNext('Start my investigation', () => { done = true; finishTask(ctx); }); } }); varBox.appendChild(vb); }); say('Now choose what you will change.', 'think'); }); labBox.appendChild(b); });
    say('First choose what you will test.', 'wave');
  }
  function taskDesignLab(ctx) {
    const cfg = LABS[derbyChoice.lab] || LABS.ramp, vk = cfg.variables[derbyChoice.vkey] ? derbyChoice.vkey : Object.keys(cfg.variables)[0];
    runLab(ctx, cfg, vk, { chosen: true, title: 'Your investigation', intro: 'You chose the question. Now run all seven steps, just like Mission Control!' });
  }
  const CARS = { height: [1, 2, 3, 4], surface: [['smooth', 'smooth floor'], ['carpet', 'carpet'], ['felt', 'felt']], mass: [0, 1, 2, 3] };
  function taskTune(ctx) {
    openTask(ctx, { title: 'Tune the Derby team', prompt: 'Pick the settings for the car and the rocket. Beat Judge Sprocket\'s team: car 170 cm and rocket 200 cm.', action: 'Race!', intro: 'Use what your investigations showed. Which settings make the car and the rocket go the farthest?', tip: 'Tip: look back at your lab data. Which settings gave the biggest distances?' });
    const mkSel = (label, opts, def) => { const lb = h('label', 'tune-row', label + ' '); const e = document.createElement('select'); opts.forEach(o => { const op = document.createElement('option'); op.value = Array.isArray(o) ? o[0] : o; op.textContent = Array.isArray(o) ? o[1] : o; e.appendChild(op); }); e.value = def; lb.appendChild(e); return { lb, e }; };
    const grid = h('div', 'tune-grid'); const c1 = h('div', 'tune-col'), c2 = h('div', 'tune-col'); c1.appendChild(h('b', null, 'THE CAR')); c2.appendChild(h('b', null, 'THE ROCKET')); grid.append(c1, c2); T.body.appendChild(grid);
    const sH = mkSel('Books:', [1, 2, 3, 4], 2), sS = mkSel('Floor:', [['smooth', 'smooth'], ['carpet', 'carpet'], ['felt', 'felt']], 'carpet'), sM = mkSel('Weights:', [0, 1, 2, 3], 2); [sH, sS, sM].forEach(x => c1.appendChild(x.lb));
    const rP = mkSel('Pumps:', [5, 10, 15], 10), rS = mkSel('String:', [['line', 'fishing line'], ['yarn', 'yarn']], 'yarn'), rC = mkSel('Weights:', [0, 1, 2, 3], 2); [rP, rS, rC].forEach(x => c2.appendChild(x.lb));
    const out = h('div', 'lab-card tune-out', 'Press Race! to see how far each one goes.'); T.body.appendChild(out);
    const carD = () => Math.round((47 * +sH.e.value - 4) * ({ smooth: 1, carpet: 0.35, felt: 0.2 })[sS.e.value] * (1 + 0.015 * +sM.e.value)), rocD = () => { const q = +rP.e.value - 5; let d = 80 + 14 * q - 0.05 * q * q; if (rS.e.value === 'yarn') d *= 0.7; return Math.round(d * Math.pow(0.88, +rC.e.value)); };
    const lad = ladder([() => ({ text: 'Look back at your investigations. Which settings gave the biggest distances?' }), () => ({ text: 'More books, a smooth floor, more air, and a smooth string all helped. Extra weight on the rocket slowed it down.' }), () => { sH.e.value = 4; sS.e.value = 'smooth'; sM.e.value = 0; rP.e.value = 15; rS.e.value = 'line'; rC.e.value = 0; return { text: 'I set the best settings. Press Race!' }; }]);
    let won = false;
    T.act.onclick = () => {
      if (won) return; const cd = carD(), rd = rocD(), okC = cd >= 170, okR = rd >= 200;
      out.innerHTML = '<div class="tune-bars">' + chartSvg([cd, 170], ['your car', 'judge'], 260) + chartSvg([rd, 200], ['your rocket', 'judge'], 260) + '</div><p>Your car: <b>' + cd + ' cm</b> (needs 170). Your rocket: <b>' + rd + ' cm</b> (needs 200).</p>';
      if (okC && okR) { won = true; T.act.hidden = true; say('You beat Judge Sprocket\'s team with both! You used your data to choose the settings.', 'cheer', 'good'); finishTask(ctx); } else lad.give(!okC && !okR ? 'Not yet. Neither beat the judge. ' : !okC ? 'The car needs more distance. ' : 'The rocket needs more distance. ');
    };
  }
  function taskFinalRound(ctx) {
    quizTask(ctx, { title: 'Final round: fair test judge', prompt: 'One last round before Derby Day!', intro: 'Judge Sprocket has a few last questions.', tip: 'Tip: one variable, constants, three trials, and averages.',
      rounds: mode => [
        { prompt: 'A student tests how the height of a ramp affects how far a toy truck rolls. Which is the variable?', options: ['The height of the ramp', 'The toy truck', 'The floor'], hint1: 'What is the student changing on purpose?', hint2: 'The variable is the one thing that changes: the ramp height.', done: 'Yes! The ramp height is the variable.' },
        { prompt: 'In that same test, which is a constant?', options: ['The floor', 'The height of the ramp', 'How far the truck rolls'], hint1: 'A constant stays the same.', hint2: 'The floor should stay the same every time.', done: 'Right! The floor is a constant.' },
        { prompt: 'The truck rolled 20, 22, and 21 cm. What is the average?', options: ['21 cm', '63 cm', '22 cm'], hint1: 'Add them and divide by 3.', hint2: '20 + 22 + 21 = 63. Then 63 divided by 3 is 21.', done: 'Yes! The average is 21 cm.' },
        { prompt: 'Why do scientists run three trials?', options: ['So one odd result cannot trick them and the data is more trustworthy.', 'Because the rule says so.', 'To make the test longer.'], hint1: 'What if one trial was weird?', hint2: 'Repeated trials make data more trustworthy.', done: 'Right! Repeated trials make the data more trustworthy.' },
        { prompt: 'A taller ramp gave 40, 85, and 130 cm for 1, 2, and 3 books. Which explanation fits the data?', options: ['A taller ramp means a bigger force pulls the car down the slope, so its motion changes more.', 'A taller ramp makes the car heavier.', 'A taller ramp removes friction.'], hint1: 'Think about forces and motion.', hint2: 'The bigger force along the slope changes the motion more.', done: 'Exactly! That connects the pattern to force and motion.' }
      ].slice(0, mode === 'easy' ? 3 : mode === 'challenge' ? 5 : 4) });
  }

  /* =====================================================================
     ENDING: Garage Door Console (type the six codes) and the race-car show
     ===================================================================== */
  function showEnding() {
    show('end', 'scene-finale');
    $('#btn-launch').textContent = 'Go to the Starting Gate!'; $('#btn-launch').disabled = false;
    $('#btn-launch').onclick = showConsole;
  }
  const normCode = v => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  function showConsole() {
    show('console', 'scene-obs');
    const rows = $('#console-rows'); rows.innerHTML = '';
    const msg = $('#console-msg'), fire = $('#btn-fire'), peek = $('#btn-peek');
    let powered = 0; fire.disabled = true; peek.hidden = true; msg.textContent = 'Gates ready: 0 of 6';
    const inputs = [];
    ZONES.forEach((z, i) => {
      const n = i + 1; const full = normCode(levelCode(n)), four = full.slice(2);
      const row = h('div', 'crow'); row.innerHTML = '<span class="cnum">' + n + '</span><span class="cname">' + z.name + '</span>';
      const inp = h('input'); inp.type = 'text'; inp.maxLength = 12; inp.autocomplete = 'off'; inp.autocapitalize = 'characters'; inp.spellcheck = false; inp.placeholder = 'L' + n + '-????';
      inp.setAttribute('aria-label', 'Level code for mission ' + n + ', ' + z.name);
      const light = h('span', 'clight cmirror'); light.setAttribute('aria-hidden', 'true'); light.innerHTML = '<svg viewBox="0 0 30 30"><rect x="6" y="13" width="18" height="12" rx="3" fill="#e8f0ff" stroke="#0b1736" stroke-width="2"/><path d="M10 13 V9 a5 5 0 0 1 10 0 V13" fill="none" stroke="#0b1736" stroke-width="3"/><circle cx="15" cy="19" r="2" fill="#0b1736"/></svg>';
      row.append(inp, light); rows.appendChild(row); inputs.push({ inp, row, full, n });
      inp.addEventListener('input', () => {
        const v = normCode(inp.value); row.classList.remove('bad');
        if (v === full || v === four) {
          inp.value = levelCode(n); inp.readOnly = true; row.classList.add('ok'); powered++;
          msg.textContent = 'Gates ready: ' + powered + ' of 6';
          if (powered === 6) { msg.textContent = 'All six gates are ready! Press START!'; fire.disabled = false; fire.focus({ preventScroll: true }); }
          else { const next = inputs.find(x => !x.row.classList.contains('ok')); if (next) next.inp.focus({ preventScroll: true }); }
        } else if (v.length >= full.length || (v.length >= 4 && v.indexOf('L' + n) !== 0)) {
          row.classList.add('bad'); peek.hidden = false;
          msg.textContent = "That code doesn't match. Check your Mission Journal page for mission " + n + '.';
        }
      });
    });
    peek.onclick = () => { inputs.forEach(x => { if (!x.row.classList.contains('ok')) x.inp.placeholder = levelCode(x.n); }); msg.textContent = 'Here are your codes. Type them in!'; };
    fire.onclick = () => { if (!fire.disabled) startDerbyShow(); };
    setTimeout(() => inputs[0].inp.focus({ preventScroll: true }), 60);
  }

  function startDerbyShow() {
    show('lightshow', 'scene-obs');
    const stage = $('#show-stage'); stage.innerHTML = ''; stage.hidden = false; $('#show-bye').hidden = true;
    const S = ms => Math.max(5, ms * SPEED);
    const svgEl = s('svg', { viewBox: '0 0 1000 560', class: 'showsvg', role: 'img', 'aria-label': 'Three cars race down the track at Derby Day and the student\'s red car wins.' }); stage.appendChild(svgEl);
    const defs = s('defs', {}, svgEl); const sk = s('linearGradient', { id: 'dsky', x1: 0, y1: 0, x2: 0, y2: 1 }, defs); s('stop', { offset: '0%', 'stop-color': '#6fb4ff' }, sk); s('stop', { offset: '100%', 'stop-color': '#dff3ff' }, sk);
    s('rect', { width: 1000, height: 560, fill: 'url(#dsky)' }, svgEl); 
    s('rect', { x: 0, y: 150, width: 1000, height: 110, fill: '#8a94b8' }, svgEl); for (let i = 0; i < 40; i++) s('rect', { x: i * 26 + 4, y: 160 + (i % 4) * 22, width: 18, height: 14, rx: 3, fill: ['#ff5a5a', '#4aa8ff', '#ffd23f', '#7fe3b0'][i % 4] }, svgEl);
    s('rect', { x: 0, y: 330, width: 1000, height: 190, fill: '#5a5a68' }, svgEl); [393, 455].forEach(y => s('line', { x1: 0, y1: y, x2: 1000, y2: y, stroke: '#fff', 'stroke-width': 4, 'stroke-dasharray': '30 22' }, svgEl));
    s('line', { x1: 100, y1: 330, x2: 100, y2: 520, stroke: '#fff', 'stroke-width': 6 }, svgEl);
    for (let r = 0; r < 12; r++) for (let c = 0; c < 2; c++) s('rect', { x: 900 + c * 18, y: 330 + r * 16, width: 18, height: 16, fill: (r + c) % 2 ? '#fff' : '#0b1736' }, svgEl);
    const lights = []; for (let i = 0; i < 6; i++) { const l = s('circle', { cx: 330 + i * 64, cy: 300, r: 16, fill: '#8f9bc4', stroke: '#0b1736', 'stroke-width': 4 }, svgEl); lights.push(l); }
    const mkCar = (y, col) => { const g = s('g', { class: 'derbycar' }, svgEl); s('rect', { x: 20, y: y - 22, width: 84, height: 26, rx: 10, fill: col, stroke: '#0b1736', 'stroke-width': 4 }, g); s('rect', { x: 40, y: y - 40, width: 40, height: 20, rx: 7, fill: col, stroke: '#0b1736', 'stroke-width': 4 }, g); [36, 90].forEach(x => { s('circle', { cx: x, cy: y + 4, r: 11, fill: '#2b3566', stroke: '#0b1736', 'stroke-width': 4 }, g); }); return g; };
    const c1 = mkCar(372, '#ff4a3a'), c2 = mkCar(432, '#2f6fe0'), c3 = mkCar(492, '#ffd23f');
    const trophy = s('g', { class: 'trophy', transform: 'translate(0,-100)' }, svgEl); s('path', { d: 'M470,200 h60 v30 q0,36 -30,40 q-30,-4 -30,-40 z', fill: '#ffd23f', stroke: '#0b1736', 'stroke-width': 4 }, trophy); s('rect', { x: 492, y: 270, width: 16, height: 26, fill: '#ffd23f', stroke: '#0b1736', 'stroke-width': 3 }, trophy); s('rect', { x: 468, y: 294, width: 64, height: 14, rx: 4, fill: '#ffd23f', stroke: '#0b1736', 'stroke-width': 3 }, trophy);
    const faces = h('div', 'show-faces sky derby', '<img src="images/bolt-cheer.png" alt="Bolt"><img src="images/judge.png" alt="Judge Sprocket">'); stage.appendChild(faces);
    const sparks = h('div', 'show-sparks'); stage.appendChild(sparks); const msg = h('div', 'show-msg'); stage.appendChild(msg);
    lights.forEach((lt, i) => setTimeout(() => { lt.setAttribute('fill', i < 5 ? '#ff5a5a' : '#6ef0a0'); }, S(300 + i * 380)));
    setTimeout(() => { c1.classList.add('go1'); c2.classList.add('go2'); c3.classList.add('go3'); }, S(2800));
    setTimeout(() => { trophy.classList.add('show'); const cols = ['#ff8a8a', '#ffb347', '#ffe27a', '#7fe3b0', '#7fc8ff', '#c9a6ff']; for (let i = 0; i < 44; i++) { const sp = h('i'); const a = Math.random() * Math.PI * 2, d = 70 + Math.random() * 160; sp.style.left = '92%'; sp.style.top = '70%'; sp.style.background = cols[i % cols.length]; const z = 8 + Math.random() * 12; sp.style.width = sp.style.height = z + 'px'; sp.style.setProperty('--dx', (Math.cos(a) * d) + 'px'); sp.style.setProperty('--dy', (Math.sin(a) * d * 0.7 - 50) + 'px'); sparks.appendChild(sp); } }, S(7200));
    setTimeout(() => { faces.classList.add('pop'); msg.textContent = 'Derby Day champion, Engineer ' + (state.name || '') + '! You designed fair tests and used your data to win!'; msg.classList.add('show'); }, S(8200));
    setTimeout(() => { stage.hidden = true; $('#show-bye').hidden = false; setScene('scene-finale'); }, S(13200));
    setTimeout(showReport, S(16600));
  }

  function showReport() {
    $('#rep-name').textContent = 'Derby Day Champion ' + state.name;
    const starCount = state.stars.filter(Boolean).length;
    $('#rep-stars').textContent = starCount + ' of 6 gold stars';
    const row = $('#rep-badges'); row.innerHTML = '';
    BADGES.forEach((bd, i) => {
      const el = h('div', 'badge small'); el.innerHTML = '<img src="images/badge-' + bd.tier + '.png" alt="">' + (state.stars[i] ? STAR_SVG : '') + '<span>' + (i + 1) + '</span>'; el.title = bd.name; row.appendChild(el);
    });
    $('#rep-code').textContent = levelCode(6);
    show('report', 'scene-finale');
  }
  $('#btn-replay').addEventListener('click', () => { state.mode = 'challenge'; save(); showMap(); toast('Challenge mode is on. Replay any station to try for gold stars!'); });
  $('#btn-report-map').addEventListener('click', showMap);

  /* =====================================================================
     LEVELS, MAP, AND INTRO
     ===================================================================== */
  const LEVELS = [
    {
      zone: 'Briefing Room', scene: 'scene-obs',
      brief: "Welcome back to Gear Up Garage, {name}! Derby Day is tomorrow, and every engineer needs the mission checklist: question, predict, plan, trials, data, pattern, explain. Let's learn how to design a fair test!",
      win: 'You know the checklist, Lab Assistant {name}!',
      log: 'Write the seven steps of the mission checklist in order. Then write what a fair test changes, what it measures, and what it keeps the same.',
      tasks: mode => [taskChecklist, taskSystemSort, taskTestable, taskVarConst, taskConnectT1]
    },
    {
      zone: 'Ramp Lab', scene: 'scene-ramp',
      brief: "This is the Ramp Lab! You will run a real investigation: how does ramp height affect how far a car rolls? You choose what to change, run the trials, measure, and explain. Just like Mystery Lab Issue 6!",
      win: 'Great investigation, Ramp Tester {name}!',
      log: 'Draw your ramp system. Label what you changed, what you measured, and what you kept the same. Write the pattern in your data.',
      tasks: mode => [taskRampLab, taskConnectT2]
    },
    {
      zone: 'Balloon Rocket Hall', scene: 'scene-rocket',
      brief: "Welcome to the Balloon Rocket Hall! A balloon on a straw on a string is a rocket. How does the amount of air change how far it travels? Plan a fair test and find out!",
      win: 'Three, two, one, liftoff! Great work, Rocket Scientist {name}!',
      log: 'Draw the balloon rocket on its string. Write your question, your averages, and a claim with evidence and reasoning.',
      tasks: mode => [taskRocketLab, taskConnectT3]
    },
    {
      zone: 'Air-Glide Disc', scene: 'scene-hover',
      brief: "At the Air-Glide Disc, a heavy disc needs to slide farther. Could an air cushion help? Design the test and see what happens to friction!",
      win: 'You made it glide, Glide Engineer {name}!',
      log: 'Draw the disc with air and without air. Show the forces. Explain how the air cushion changed friction and motion.',
      tasks: mode => [taskDiscLab, taskConnectT4]
    },
    {
      zone: "Judges' Table", scene: 'scene-derby',
      brief: "Welcome to the Judges' Table! Judge Sprocket checks every test for mistakes. Can you spot them, find the averages, read the graphs, and pick the fair plan?",
      win: 'The judges approve! You are a Fair Test Judge, {name}!',
      log: 'Write a fair-test rule for each part: what you change, what you measure, and what you keep the same. Explain why we run three trials.',
      tasks: mode => [taskMistakes, taskAverages, taskReadGraph, taskFairJudge, taskConnectT5]
    },
    {
      zone: 'Derby Day', scene: 'scene-derby', final: true,
      brief: "{name}, it is Derby Day! Plan your own investigation, run it like a real scientist, then use your data to tune the winning car and rocket. Judge Sprocket is watching!",
      win: "Derby Day champion! You did it, {name}!",
      log: 'Write your question, your prediction, what you changed, measured, and kept the same, and your explanation from your Derby Day investigation.',
      tasks: mode => [taskChoose, taskDesignLab, taskTune, taskFinalRound]
    }
  ];

  function playLevel(i) {
    const L = LEVELS[i]; state.level = i; state.hints = 0;
    $('#brief-text').textContent = fill(L.brief);
    show('brief', L.scene);
    $('#btn-brief-next').onclick = () => runTask(0);
  }
  function runTask(n) {
    const L = LEVELS[state.level]; const list = L.tasks(state.mode);
    if (n >= list.length) { levelWin(); return; }
    list[n]({ index: n, total: list.length, next: () => runTask(n + 1) });
  }
  function levelWin() {
    const L = LEVELS[state.level];
    state.done = Math.max(state.done, state.level + 1); save();
    $('#win-text').textContent = fill(L.win);
    $('#win-meter').textContent = 'Garage power: ' + METER[state.done] + '%';
    const bd = BADGES[state.level];
    $('#badge-img').src = 'images/badge-' + bd.tier + '.png'; $('#badge-label').textContent = bd.label;
    const perfect = state.hints === 0; if (perfect) { state.stars[state.level] = true; save(); }
    $('#badge-star-slot').innerHTML = perfect ? STAR_SVG : '';
    $('#badge-text').innerHTML = 'Badge earned: ' + bd.name + (perfect ? '<br><span class="bonus">Bonus gold star: no hints needed!</span>' : '<br><span class="bonus soft">Replay this level anytime to try for the gold star.</span>');
    show('win', L.scene);
    $('#btn-win-next').onclick = showLog;
  }
  function showLog() {
    const L = LEVELS[state.level];
    $('#log-text').textContent = fill(L.log);
    $('#log-code').textContent = levelCode(state.level + 1);
    show('log', L.scene);
    $('#btn-log-done').onclick = L.final ? showEnding : (state.path === 'quick' ? showQuickEnd : showMap);
  }
  function showQuickEnd() {
    const bd = BADGES[0]; $('#quick-badge').innerHTML = '<img src="images/badge-' + bd.tier + '.png" alt=""><span>' + bd.label + '</span>' + (state.stars[0] ? STAR_SVG : '');
    $('#quick-code').textContent = levelCode(1);
    show('quick', 'scene-obs');
  }
  $('#btn-quick-full').addEventListener('click', () => { state.path = 'full'; save(); showMap(); });
  $('#btn-quick-again').addEventListener('click', () => { state.hints = 0; playLevel(0); });

  /* ---------- the observatory map ---------- */
  // Positions are percentages of the map picture (each ring sits over its station)
  const ZONES = [
    { name: 'Briefing Room', short: 'Briefing Room', x: 19, y: 23 },
    { name: 'Ramp Lab', short: 'Ramp Lab', x: 50, y: 25 },
    { name: 'Balloon Rocket Hall', short: 'Rocket Hall', x: 83, y: 24 },
    { name: 'Air-Glide Disc', short: 'Air-Glide Disc', x: 20, y: 68 },
    { name: "Judges' Table", short: "Judges' Table", x: 50, y: 74 },
    { name: 'Derby Day', short: 'Derby Day', x: 83, y: 68 }
  ];
  function showMap() {
    const map = $('#map'); map.innerHTML = '';
    ZONES.forEach((z, i) => {
      const st = i < state.done ? 'lit' : i === state.done ? 'open' : 'locked';
      const status = st === 'lit' ? '\uD83D\uDCA1' : st === 'open' ? '\u25B6' : '\uD83D\uDD12';
      const b = h('button', 'zone', '<span class="zone-ring"></span><span class="zone-status">' + status + '</span><span class="zone-name">' + z.short + '</span>');
      b.type = 'button'; b.dataset.state = st; b.style.left = z.x + '%'; b.style.top = z.y + '%';
      b.setAttribute('aria-label', z.name + (st === 'lit' ? ', done' : st === 'open' ? ', ready' : ', locked'));
      b.addEventListener('click', () => {
        if (LEVELS[i] && st !== 'locked') playLevel(i);
        else if (st === 'locked') toast('Finish the earlier stations first!');
      });
      map.appendChild(b);
    });
    const fixed = Math.min(state.done, 6);
    $('#map-note').textContent = fixed === 0 ? "The Test Track needs engineers. Start in the Briefing Room!" : fixed + ' of 6 stations done. The garage is ' + METER[Math.min(state.done, 6)] + '% powered.';
    const bw = $('#map-badges'); bw.innerHTML = '';
    BADGES.forEach((bd, i) => {
      const earned = i < state.done; const el = h('div', 'badge small' + (earned ? '' : ' empty'));
      el.innerHTML = (earned ? '<img src="images/badge-' + bd.tier + '.png" alt="">' : '') + (earned && state.stars[i] ? STAR_SVG : '') + '<span>' + (earned ? (i + 1) : '?') + '</span>';
      el.title = earned ? bd.name + (state.stars[i] ? ' (gold star)' : '') : 'Not earned yet'; bw.appendChild(el);
    });
    show('map', 'scene-map');
  }

  /* ---------- intro wiring ---------- */
  $('#btn-start').addEventListener('click', () => {
    $('#name-input').value = state.name;
    const r = $('input[name="mode"][value="' + state.mode + '"]'); if (r) r.checked = true;
    const p = $('input[name="path"][value="' + state.path + '"]'); if (p) p.checked = true;
    $('#btn-name-next').disabled = !state.name.trim();
    show('name', 'scene-obs');
    setTimeout(() => $('#name-input').focus({ preventScroll: true }), 50);
  });
  $('#name-input').addEventListener('input', e => { $('#btn-name-next').disabled = !e.target.value.trim(); });
  $('#name-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !$('#btn-name-next').disabled) $('#btn-name-next').click(); });
  $('#btn-name-next').addEventListener('click', () => {
    const nm = $('#name-input').value.trim().slice(0, 18);
    if (!nm) return;
    if (nm.toLowerCase() !== state.name.trim().toLowerCase()) { state.done = 0; state.stars = []; } // a new engineer starts fresh
    state.name = nm;
    const m = $('input[name="mode"]:checked'); state.mode = m ? m.value : 'standard';
    const p = $('input[name="path"]:checked'); state.path = p ? p.value : 'full';
    save();
    if (state.path === 'quick') { $('#btn-zib-next').textContent = 'Start the Briefing Room'; show('zib', 'scene-obs'); }
    else { $('#btn-zib-next').textContent = 'Begin the mission'; show('news', 'scene-obs'); }
  });
  $('#btn-news-next').addEventListener('click', () => show('volta', 'scene-obs'));
  $('#btn-volta-next').addEventListener('click', () => show('zib', 'scene-obs'));
  $('#btn-zib-next').addEventListener('click', () => { if (state.path === 'quick') { state.hints = 0; playLevel(0); } else showMap(); });

  // preload every character image so poses swap instantly
  ['bolt-wave', 'bolt-worried', 'bolt-cheer', 'bolt-think', 'coach', 'judge', 'tv-frame', 'badge-bronze', 'badge-silver', 'badge-gold'].forEach(n => { const i = new Image(); i.src = 'images/' + n + '.png'; });

  if (window.OBH_TEST) window.__obh = { state, playLevel, runTask, showMap, BADGES, showEnding, showReport, showConsole, levelCode, showQuickEnd, ZONES, LEVELS, CONNECTS: [CONNECT_T1, CONNECT_T2, CONNECT_T3, CONNECT_T4, CONNECT_T5], boards: () => activeBoards };

  load();
  show('title', 'scene-title');
})();
